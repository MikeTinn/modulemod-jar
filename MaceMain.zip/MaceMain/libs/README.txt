Put your built AUTISM Client jar in this folder (for compiling only).
