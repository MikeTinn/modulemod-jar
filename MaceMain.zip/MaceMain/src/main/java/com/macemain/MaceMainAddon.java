package com.macemain;

import autismclient.api.ApiVersion;
import autismclient.api.AutismAddon;
import autismclient.api.AutismAddons;
import com.macemain.modules.AutoStunslamModule;
import com.macemain.modules.MaceAuraModule;
import com.macemain.modules.MaceSwapModule;
import com.macemain.modules.SpearMacroModule;

// Addon entrypoint (the "autism" entrypoint in fabric.mod.json).
// All four modules auto-group under a menu column named after this addon (MaceMain).
public final class MaceMainAddon extends AutismAddon {
    public static final String ID = "macemain";

    @Override
    public int apiVersion() {
        return ApiVersion.CURRENT;
    }

    @Override
    public void onInitialize() {
        AutismAddons.modules().register(new MaceAuraModule());
        AutismAddons.modules().register(new SpearMacroModule());
        AutismAddons.modules().register(new MaceSwapModule());
        AutismAddons.modules().register(new AutoStunslamModule());
    }

    @Override
    public String getPackage() {
        return "com.macemain";
    }
}
