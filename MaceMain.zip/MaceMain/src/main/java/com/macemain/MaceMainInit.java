package com.macemain;

import net.fabricmc.api.ClientModInitializer;

// Fabric's required client entrypoint. The addon's real work is in MaceMainAddon.
public final class MaceMainInit implements ClientModInitializer {
    @Override
    public void onInitializeClient() {}
}
