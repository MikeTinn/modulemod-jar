package com.macemain.modules;

import autismclient.api.module.BoolSetting;
import autismclient.api.module.ChoiceSetting;
import autismclient.api.module.IntSetting;
import autismclient.modules.Module;
import autismclient.util.AutismCpsTracker;
import autismclient.util.AutismInventoryHelper;
import com.macemain.MaceMainAddon;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.function.Predicate;

// Auto Stunslam: when the player you are LOOKING AT is blocking with a shield, quickly hits them with an
// axe to disable the shield, then swaps to a mace and smashes them.
//
//   EQUIP_AXE -> HIT_AXE -> EQUIP_MACE -> HIT_MACE -> RESTORE
//
// Safety rules: it only ever targets a player that is under your crosshair (checked again before every hit,
// with a line-of-sight check), and it needs both an axe and a mace before it starts - otherwise it does nothing
// and your click goes through normally.
//
// Credit: the "would this hit be blocked" maths is adapted from AUTISM Client's own KillAuraModule
// (wouldBlockHit / getBlockedDamage). No outside code was used.
public final class AutoStunslamModule extends Module {
    private final ChoiceSetting trigger = add(new ChoiceSetting("trigger", "Trigger", "On Click",
        "On Click", "Automatic").group("General"));
    private final ChoiceSetting speed = add(new ChoiceSetting("speed", "Swap Speed", "Fast",
        "Instant", "Fast", "Normal").group("Timing"));
    private final BoolSetting onlyWhenSmashReady = add(new BoolSetting("smash-ready", "Only When Smash Ready", true)
        .group("General"));
    private final BoolSetting searchInventory = add(new BoolSetting("search-inventory", "Find Items In Inventory", true)
        .group("Items"));
    private final BoolSetting swapBack = add(new BoolSetting("swap-back", "Swap Back When Done", true)
        .group("Items"));
    private final IntSetting cooldown = add(new IntSetting("cooldown", "Cooldown (ticks)", 20, 0, 100, 1)
        .group("Timing")
        .visibleWhen(() -> "Automatic".equals(trigger.get())));

    private enum Step { EQUIP_AXE, HIT_AXE, EQUIP_MACE, HIT_MACE, RESTORE, DONE }

    private static final int MAX_RUN_TICKS = 40;

    private Step step = Step.DONE;
    private int wait;
    private int runTicks;
    private int cooldownLeft;
    private Player target;
    private int originalSlot = -1;
    // Every inventory<->hotbar swap we made as {inventorySlot, hotbarSlot}; undone in reverse order.
    private final Deque<int[]> swaps = new ArrayDeque<>();

    public AutoStunslamModule() {
        super(MaceMainAddon.ID + ":auto-stunslam", "Auto Stunslam", "Axe to break the shield, then mace.");
    }

    @Override
    public void onDisable() {
        if (step != Step.DONE) restore();
        reset();
        cooldownLeft = 0;
    }

    @Override
    public void onGameLeft() {
        swaps.clear();
        reset();
    }

    // "On Click" trigger: the click on a shielding player is taken over by the stunslam.
    // Every other click (no shield, not a player, missing items, not smash-ready) goes through untouched.
    @Override
    public boolean shouldCancelAttack(HitResult hitResult) {
        if (!"On Click".equals(trigger.get())) return false;
        if (step != Step.DONE || cooldownLeft > 0 || MC.player == null || MC.level == null) return false;
        if (!(hitResult instanceof EntityHitResult entityHit)) return false;
        if (!(entityHit.getEntity() instanceof Player player) || !validTarget(player)) return false;
        if (!canStart(player)) return false;

        begin(player);
        return true;
    }

    @Override
    public void tick() {
        if (MC.player == null || MC.level == null || MC.gameMode == null) {
            if (step != Step.DONE) {
                swaps.clear();
                reset();
            }
            return;
        }

        if (cooldownLeft > 0) cooldownLeft--;

        if (step == Step.DONE) {
            if ("Automatic".equals(trigger.get())) tryAutoStart();
            return;
        }

        // Watchdog: never stay mid-run for long.
        if (++runTicks > MAX_RUN_TICKS && step != Step.RESTORE) step = Step.RESTORE;

        if (wait > 0) {
            wait--;
            return;
        }

        // With "Instant" every step runs in the same tick.
        do {
            switch (step) {
                case EQUIP_AXE -> equipAxe();
                case HIT_AXE -> hitAxe();
                case EQUIP_MACE -> equipMace();
                case HIT_MACE -> hitMace();
                case RESTORE -> {
                    restore();
                    reset();
                    cooldownLeft = "Automatic".equals(trigger.get()) ? cooldown.get() : 0;
                }
                case DONE -> { }
            }
        } while (step != Step.DONE && wait == 0 && delayTicks() == 0);
    }

    // ---- start conditions ------------------------------------------------------------------

    private void tryAutoStart() {
        if (cooldownLeft > 0 || MC.screen != null) return;
        if (!MC.player.getMainHandItem().is(Items.MACE)) return;
        Player aimed = aimedPlayer();
        if (aimed != null && canStart(aimed)) begin(aimed);
    }

    private boolean canStart(Player player) {
        if (!isShielding(player)) return false;
        if (onlyWhenSmashReady.get() && !MaceItem.canSmashAttack(MC.player)) return false;
        return hasItem(AutoStunslamModule::isAxe) && hasItem(AutoStunslamModule::isMace);
    }

    private void begin(Player player) {
        target = player;
        originalSlot = MC.player.getInventory().getSelectedSlot();
        swaps.clear();
        runTicks = 0;
        wait = 0;
        step = Step.EQUIP_AXE;
    }

    // ---- steps -----------------------------------------------------------------------------

    private void equipAxe() {
        if (!stillValid() || !equip(AutoStunslamModule::isAxe)) {
            step = Step.RESTORE;
            return;
        }
        step = Step.HIT_AXE;
        wait = delayTicks();
    }

    private void hitAxe() {
        // Re-check every time: the target must still be under the crosshair.
        if (!stillValid() || !isAxe(MC.player.getMainHandItem())) {
            step = Step.RESTORE;
            return;
        }
        attack(target);
        step = Step.EQUIP_MACE;
        wait = delayTicks();
    }

    private void equipMace() {
        if (!stillValid() || !equip(AutoStunslamModule::isMace)) {
            step = Step.RESTORE;
            return;
        }
        step = Step.HIT_MACE;
        wait = delayTicks();
    }

    private void hitMace() {
        boolean smashOk = !onlyWhenSmashReady.get() || MaceItem.canSmashAttack(MC.player);
        if (stillValid() && smashOk && isMace(MC.player.getMainHandItem())) {
            attack(target);
        }
        step = Step.RESTORE;
        wait = 0;
    }

    private void restore() {
        if (MC.player == null) {
            swaps.clear();
            return;
        }
        // Undo inventory swaps newest-first so every item lands back in its original slot.
        while (!swaps.isEmpty()) {
            int[] swap = swaps.pop();
            AutismInventoryHelper.restoreInventoryHotbarSwap(MC, swap[0], swap[1]);
        }
        if (swapBack.get() && originalSlot >= 0) {
            AutismInventoryHelper.selectHotbarSlot(MC, originalSlot);
        }
    }

    private void reset() {
        step = Step.DONE;
        wait = 0;
        runTicks = 0;
        target = null;
        originalSlot = -1;
    }

    // ---- helpers ---------------------------------------------------------------------------

    private boolean stillValid() {
        return target != null && validTarget(target) && aimedPlayer() == target;
    }

    private int delayTicks() {
        return switch (speed.get()) {
            case "Instant" -> 0;
            case "Normal" -> 2;
            default -> 1; // Fast
        };
    }

    private void attack(LivingEntity victim) {
        MC.getConnection().send(new ServerboundAttackPacket(victim.getId()));
        if (!MC.gameMode.isSpectator()) {
            MC.player.attack(victim);
            MC.player.resetAttackStrengthTicker();
        }
        MC.player.swing(InteractionHand.MAIN_HAND);
        AutismCpsTracker.recordLeft();
    }

    private boolean hasItem(Predicate<ItemStack> wanted) {
        var inv = MC.player.getInventory();
        int limit = searchInventory.get() ? 36 : 9;
        for (int slot = 0; slot < limit; slot++) {
            if (wanted.test(inv.getItem(slot))) return true;
        }
        return false;
    }

    // Makes the wanted item the one in your hand: held -> hotbar -> (optionally) swapped in from the inventory.
    private boolean equip(Predicate<ItemStack> wanted) {
        var inv = MC.player.getInventory();
        int selected = inv.getSelectedSlot();
        if (wanted.test(inv.getItem(selected))) return true;

        for (int slot = 0; slot < 9; slot++) {
            if (wanted.test(inv.getItem(slot))) {
                AutismInventoryHelper.selectHotbarSlot(MC, slot);
                return inv.getSelectedSlot() == slot;
            }
        }
        if (searchInventory.get()) {
            for (int slot = 9; slot < 36; slot++) {
                if (wanted.test(inv.getItem(slot))) {
                    if (!AutismInventoryHelper.swapInventorySlots(MC, slot, selected)) return false;
                    swaps.push(new int[] { slot, selected });
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean isAxe(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.is(ItemTags.AXES);
    }

    private static boolean isMace(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.is(Items.MACE);
    }

    private boolean validTarget(Entity entity) {
        return entity instanceof Player player
            && player != MC.player
            && player.isAlive()
            && !player.isSpectator();
    }

    // The player under your crosshair within reach, with nothing solid in between. Null if none.
    private Player aimedPlayer() {
        if (MC.player == null || MC.level == null) return null;
        Vec3 eyes = MC.player.getEyePosition();
        Vec3 dir = MC.player.getViewVector(1.0F);
        double range = MC.player.entityInteractionRange();
        Vec3 end = eyes.add(dir.x * range, dir.y * range, dir.z * range);
        AABB search = MC.player.getBoundingBox().expandTowards(dir.scale(range)).inflate(1.0D);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(
            MC.player, eyes, end, search, EntitySelector.CAN_BE_PICKED.and(this::validTarget), range * range);
        if (hit == null) return null;
        HitResult wall = MC.level.clip(new ClipContext(
            eyes, hit.getLocation(), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, MC.player));
        if (wall.getType() != HitResult.Type.MISS) return null;
        return hit.getEntity() instanceof Player player ? player : null;
    }

    // Would a hit from us be blocked by the target's shield right now? (Adapted from AUTISM's KillAuraModule.)
    private boolean isShielding(LivingEntity victim) {
        ItemStack blocking = victim.getItemBlockingWith();
        if (blocking == null) return false;
        var blocksAttacks = blocking.get(DataComponents.BLOCKS_ATTACKS);
        if (blocksAttacks == null) return false;

        DamageSource source = victim.level().damageSources().playerAttack(MC.player);
        if (blocksAttacks.bypassedBy().map(tag -> tag.contains(source.typeHolder())).orElse(false)) return false;

        double horizontalAngle = Math.PI;
        Vec3 sourcePosition = source.getSourcePosition();
        if (sourcePosition != null) {
            Vec3 view = victim.calculateViewVector(0.0F, victim.getYHeadRot());
            Vec3 to = sourcePosition.subtract(victim.position());
            Vec3 sourceDirection = new Vec3(to.x, 0.0D, to.z).normalize();
            horizontalAngle = Math.acos(sourceDirection.dot(view));
        }
        return blocksAttacks.resolveBlockedDamage(source, 1.0F, horizontalAngle) > 0.0F;
    }
}
