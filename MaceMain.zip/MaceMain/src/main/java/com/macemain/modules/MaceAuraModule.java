package com.macemain.modules;

import autismclient.api.module.BoolSetting;
import autismclient.api.module.DoubleSetting;
import autismclient.modules.Module;
import com.macemain.MaceMainAddon;

// Mace Aura: smoothly turns your head to the nearest player (aim-assist style), swaps to a mace and hits them.
// STATUS: settings only - combat logic is added in the next step.
public final class MaceAuraModule extends Module {
    private final DoubleSetting range = add(new DoubleSetting("range", "Range", 4.5, 1.0, 6.0, 0.1)
        .group("Targeting"));
    private final DoubleSetting turnSpeed = add(new DoubleSetting("turn-speed", "Head Turn Speed", 40.0, 1.0, 100.0, 1.0)
        .group("Aim"));
    private final BoolSetting smashHit = add(new BoolSetting("smash-hit", "Smash Hitting", true)
        .group("Combat"));
    private final BoolSetting swapOutElytra = add(new BoolSetting("swap-out-elytra", "Swap Out Of Elytra", true)
        .group("Combat"));
    private final DoubleSetting minDamage = add(new DoubleSetting("min-damage", "Minimum Damage", 6.0, 0.0, 60.0, 0.5)
        .group("Combat"));

    public MaceAuraModule() {
        super(MaceMainAddon.ID + ":mace-aura", "Mace Aura", "Aims at players and hits them with a mace.");
    }

    @Override
    public void tick() {
        // TODO(step 2): target selection, smooth rotation, mace swap, elytra swap, min-damage check.
    }
}
