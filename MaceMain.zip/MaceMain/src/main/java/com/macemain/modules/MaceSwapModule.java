package com.macemain.modules;

import autismclient.api.module.BoolSetting;
import autismclient.api.module.ChoiceSetting;
import autismclient.modules.Module;
import autismclient.util.AutismCpsTracker;
import autismclient.util.AutismInventoryHelper;
import com.macemain.MaceMainAddon;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

// Mace Swap: every time you hit something with a sword, it swaps to a mace (breach swap),
// hits the same target with it, then swaps back to your sword.
//
// Steps after a sword hit: SWAP (select mace) -> HIT (attack with mace) -> BACK (re-select sword slot),
// with a speed-dependent number of ticks between each step.
public final class MaceSwapModule extends Module {
    private final ChoiceSetting speed = add(new ChoiceSetting("speed", "Swap Speed", "Fast",
        "Instant", "Fast", "Normal", "Slow").group("Swap"));
    private final BoolSetting hitWithMace = add(new BoolSetting("hit-with-mace", "Hit With Mace", true)
        .group("Swap"));
    private final BoolSetting swapBack = add(new BoolSetting("swap-back", "Swap Back To Sword", true)
        .group("Swap"));
    private final BoolSetting searchInventory = add(new BoolSetting("search-inventory", "Find Mace In Inventory", true)
        .group("Swap"));

    private enum Step { SWAP, HIT, BACK, DONE }

    private Step step = Step.DONE;
    private int wait;
    private LivingEntity target;
    private int swordSlot = -1;
    // Set when the mace was pulled from the main inventory, so it can be put back afterwards.
    private int inventorySlotUsed = -1;

    public MaceSwapModule() {
        super(MaceMainAddon.ID + ":mace-swap", "Mace Swap", "Swaps to a mace after sword hits (breach swap).");
    }

    @Override
    public void onDisable() {
        if (step == Step.HIT || step == Step.BACK) finish();
        reset();
    }

    // Called on every left-click attack, before the vanilla attack runs. We never cancel it:
    // the sword hit goes through, and we only note that a sword hit happened.
    @Override
    public boolean shouldCancelAttack(HitResult hitResult) {
        if (step != Step.DONE || MC.player == null) return false;
        if (!(hitResult instanceof EntityHitResult entityHit)) return false;
        if (!(entityHit.getEntity() instanceof LivingEntity living)) return false;
        if (!MC.player.getMainHandItem().is(ItemTags.SWORDS)) return false;

        target = living;
        swordSlot = MC.player.getInventory().getSelectedSlot();
        step = Step.SWAP;
        wait = delayTicks();
        return false;
    }

    @Override
    public void tick() {
        if (MC.player == null || MC.gameMode == null || step == Step.DONE) return;

        if (target == null || !target.isAlive() || target.isRemoved()) {
            // Target is gone: just put things back.
            if (step == Step.HIT) step = Step.BACK;
            else if (step == Step.SWAP) {
                reset();
                return;
            }
        }

        if (wait > 0) {
            wait--;
            return;
        }

        do {
            switch (step) {
                case SWAP -> doSwap();
                case HIT -> doHit();
                case BACK -> {
                    finish();
                    reset();
                }
                case DONE -> { }
            }
        } while (step != Step.DONE && wait == 0 && delayTicks() == 0);
    }

    // ---- steps -----------------------------------------------------------------------------

    private void doSwap() {
        int maceSlot = findMace();
        if (maceSlot < 0) {
            reset();
            return;
        }
        int selected = MC.player.getInventory().getSelectedSlot();
        if (maceSlot >= 9) {
            if (!AutismInventoryHelper.swapInventorySlots(MC, maceSlot, selected)) {
                reset();
                return;
            }
            inventorySlotUsed = maceSlot;
            maceSlot = selected;
        }
        AutismInventoryHelper.selectHotbarSlot(MC, maceSlot);
        step = hitWithMace.get() ? Step.HIT : Step.BACK;
        wait = delayTicks();
    }

    private void doHit() {
        if (target != null && target.isAlive() && MC.player.getMainHandItem().is(Items.MACE)
            && MC.player.distanceToSqr(target) <= 36.0D) {
            MC.getConnection().send(new ServerboundAttackPacket(target.getId()));
            if (!MC.gameMode.isSpectator()) {
                MC.player.attack(target);
                MC.player.resetAttackStrengthTicker();
            }
            MC.player.swing(InteractionHand.MAIN_HAND);
            AutismCpsTracker.recordLeft();
        }
        step = Step.BACK;
        wait = delayTicks();
    }

    private void finish() {
        if (MC.player == null) return;
        if (inventorySlotUsed >= 9 && swordSlot >= 0) {
            AutismInventoryHelper.swapInventorySlots(MC, inventorySlotUsed, swordSlot);
        }
        inventorySlotUsed = -1;
        if (swapBack.get() && swordSlot >= 0) {
            AutismInventoryHelper.selectHotbarSlot(MC, swordSlot);
        }
    }

    private void reset() {
        step = Step.DONE;
        wait = 0;
        target = null;
        swordSlot = -1;
        inventorySlotUsed = -1;
    }

    // ---- helpers ---------------------------------------------------------------------------

    private int delayTicks() {
        return switch (speed.get()) {
            case "Instant" -> 0;
            case "Normal" -> 2;
            case "Slow" -> 4;
            default -> 1; // Fast
        };
    }

    // 0-8 hotbar, 9-35 inventory, -1 if there is no mace.
    private int findMace() {
        var inv = MC.player.getInventory();
        for (int slot = 0; slot < 9; slot++) {
            if (isMace(inv.getItem(slot))) return slot;
        }
        if (searchInventory.get()) {
            for (int slot = 9; slot < 36; slot++) {
                if (isMace(inv.getItem(slot))) return slot;
            }
        }
        return -1;
    }

    private static boolean isMace(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.is(Items.MACE);
    }
}
