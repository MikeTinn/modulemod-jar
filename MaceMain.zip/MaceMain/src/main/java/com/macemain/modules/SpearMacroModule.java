package com.macemain.modules;

import autismclient.api.module.BoolSetting;
import autismclient.api.module.DoubleSetting;
import autismclient.api.module.IntSetting;
import autismclient.modules.Module;
import autismclient.util.AutismClientMessaging;
import autismclient.util.AutismCpsTracker;
import autismclient.util.AutismInventoryHelper;
import com.macemain.MaceMainAddon;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

// Spear Macro: finds a spear (hotbar first, then inventory), switches to it, hits, then switches back
// to the 1st hotbar slot. Toggle it on (give it a keybind in the menu) to run the macro once.
//
// Steps: SWITCH -> HIT -> BACK, with "Action Delay" ticks between each step.
public final class SpearMacroModule extends Module {
    private final IntSetting delay = add(new IntSetting("delay", "Action Delay (ticks)", 1, 0, 20, 1)
        .group("Timing"));
    private final BoolSetting searchInventory = add(new BoolSetting("search-inventory", "Find Spear In Inventory", true)
        .group("Spear"));
    private final BoolSetting requireTarget = add(new BoolSetting("require-target", "Only Hit If Looking At Entity", true)
        .group("Hit"));
    private final DoubleSetting reach = add(new DoubleSetting("reach", "Reach", 4.5, 2.0, 6.0, 0.1)
        .group("Hit")
        .visibleWhen(requireTarget::get));
    private final BoolSetting autoDisable = add(new BoolSetting("auto-disable", "Turn Off After Run", true)
        .group("General"));

    private enum Step { SWITCH, HIT, BACK, DONE }

    private Step step = Step.DONE;
    private int wait;
    // Where we took the spear from, so the inventory can be put back as it was.
    private int originalHotbarSlot = -1;
    private int inventorySlotUsed = -1;

    public SpearMacroModule() {
        super(MaceMainAddon.ID + ":spear-macro", "Spear Macro", "Switches to a spear, hits, then switches back to slot 1.");
    }

    @Override
    public void onEnable() {
        startRun();
    }

    @Override
    public void onDisable() {
        // Disabled mid-run: still return to slot 1 and restore the inventory.
        if (step == Step.HIT || step == Step.BACK) finishRun();
        step = Step.DONE;
    }

    @Override
    public void tick() {
        if (MC.player == null || MC.gameMode == null || step == Step.DONE) return;

        if (wait > 0) {
            wait--;
            return;
        }

        // With a delay of 0 all three steps happen in the same tick.
        do {
            switch (step) {
                case SWITCH -> doSwitch();
                case HIT -> doHit();
                case BACK -> {
                    finishRun();
                    step = Step.DONE;
                    if (autoDisable.get()) setEnabled(false);
                    else startRun();
                }
                case DONE -> { }
            }
        } while (step != Step.DONE && wait == 0 && delay.get() == 0);
    }

    // ---- steps -----------------------------------------------------------------------------

    private void startRun() {
        step = Step.SWITCH;
        wait = 0;
        originalHotbarSlot = -1;
        inventorySlotUsed = -1;
    }

    private void doSwitch() {
        int spearSlot = findSpear();
        if (spearSlot < 0) {
            AutismClientMessaging.sendPrefixed("\u00a7cSpear Macro: no spear found.");
            step = Step.DONE;
            if (autoDisable.get()) setEnabled(false);
            return;
        }

        int selected = MC.player.getInventory().getSelectedSlot();
        if (spearSlot >= 9) {
            // Spear is in the main inventory: swap it into the slot we are holding right now.
            if (!AutismInventoryHelper.swapInventorySlots(MC, spearSlot, selected)) {
                step = Step.DONE;
                if (autoDisable.get()) setEnabled(false);
                return;
            }
            originalHotbarSlot = selected;
            inventorySlotUsed = spearSlot;
            spearSlot = selected;
        }

        AutismInventoryHelper.selectHotbarSlot(MC, spearSlot);
        step = Step.HIT;
        wait = delay.get();
    }

    private void doHit() {
        ItemStack held = MC.player.getMainHandItem();
        var piercing = held.get(DataComponents.PIERCING_WEAPON);

        if (piercing != null && !MC.gameMode.isSpectator() && (!requireTarget.get() || lookingAtEntity())) {
            MC.gameMode.piercingAttack(piercing);
            MC.player.swing(InteractionHand.MAIN_HAND);
            AutismCpsTracker.recordLeft();
        }

        step = Step.BACK;
        wait = delay.get();
    }

    private void finishRun() {
        if (MC.player == null) return;
        // Put the spear back where it came from (if it came from the inventory), then go to slot 1.
        if (inventorySlotUsed >= 9 && originalHotbarSlot >= 0) {
            AutismInventoryHelper.swapInventorySlots(MC, inventorySlotUsed, originalHotbarSlot);
        }
        inventorySlotUsed = -1;
        originalHotbarSlot = -1;
        AutismInventoryHelper.selectHotbarSlot(MC, 0);
    }

    // ---- helpers ---------------------------------------------------------------------------

    // Spear detection: any item with the piercing-weapon component (all spear tiers).
    private static boolean isSpear(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.get(DataComponents.PIERCING_WEAPON) != null;
    }

    // Returns 0-8 for a hotbar slot, 9-35 for an inventory slot, -1 if none. Prefers the held item.
    private int findSpear() {
        var inv = MC.player.getInventory();
        int selected = inv.getSelectedSlot();
        if (isSpear(inv.getItem(selected))) return selected;
        for (int slot = 0; slot < 9; slot++) {
            if (isSpear(inv.getItem(slot))) return slot;
        }
        if (searchInventory.get()) {
            for (int slot = 9; slot < 36; slot++) {
                if (isSpear(inv.getItem(slot))) return slot;
            }
        }
        return -1;
    }

    private boolean lookingAtEntity() {
        Entity camera = MC.getCameraEntity();
        if (camera == null) return false;
        double range = reach.get();
        Vec3 eyes = camera.getEyePosition();
        Vec3 dir = camera.getViewVector(1.0F);
        Vec3 end = eyes.add(dir.x * range, dir.y * range, dir.z * range);
        AABB search = camera.getBoundingBox().expandTowards(dir.scale(range)).inflate(1.0D);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(
            camera, eyes, end, search, EntitySelector.CAN_BE_PICKED, range * range);
        return hit != null;
    }
}
