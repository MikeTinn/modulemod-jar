# Modules Mod (Fabric 1.21.11)

Client-side mod with 5 modules: Scoreboard, Tab, Aspect Ratio, Chat, Hitbox.
Press RIGHT SHIFT in game to open the menu (rebind in Controls).

Build: push to GitHub, Actions tab -> Build -> download the jar artifact.
