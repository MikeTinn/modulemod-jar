package com.modulesmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ModuleListScreen extends Screen {
	private static final int W = 360;
	private static final int ROW_H = 36;
	private static final int GAP = 4;

	private final Screen parent;
	private String query = "";
	private TextFieldWidget search;
	private final List<Row> rows = new ArrayList<>();

	private record Row(Module module, ButtonWidget button) {}

	public ModuleListScreen(Screen parent) {
		super(Text.literal("Modules"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		rows.clear();
		int left = (width - W) / 2;

		search = new TextFieldWidget(textRenderer, left, 16, W, 20, Text.literal("Search"));
		search.setPlaceholder(Text.literal("Search..."));
		search.setText(query);
		search.setChangedListener(s -> {
			query = s;
			clearAndInit();
		});
		addDrawableChild(search);
		setInitialFocus(search);

		int y = 46;
		for (Module m : Modules.ALL) {
			if (!query.isEmpty() && !m.name.toLowerCase().contains(query.toLowerCase())) continue;
			ButtonWidget b = ButtonWidget.builder(Text.empty(),
					btn -> client.setScreen(new ModuleSettingsScreen(this, m)))
					.dimensions(left, y, W, ROW_H).build();
			addDrawableChild(b);
			rows.add(new Row(m, b));
			y += ROW_H + GAP;
		}

		addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
				.dimensions(width / 2 - 100, height - 28, 200, 20).build());
	}

	@Override
	public void close() {
		client.setScreen(parent);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		ctx.drawTextWithShadow(textRenderer, "Modules", (width - textRenderer.getWidth("Modules")) / 2, 4, 0xFFFFFFFF);

		for (Row r : rows) drawRow(ctx, r);

		if (rows.isEmpty()) {
			String msg = "No modules found";
			ctx.drawTextWithShadow(textRenderer, msg, (width - textRenderer.getWidth(msg)) / 2, 60, 0xFFAAAAAA);
		}
	}

	private void drawRow(DrawContext ctx, Row r) {
		Module m = r.module();
		int x = r.button().getX();
		int y = r.button().getY();

		// icon: three little sliders
		ctx.fill(x + 4, y + 4, x + 32, y + 32, 0xFF0B1226);
		for (int i = 0; i < 3; i++) {
			int ly = y + 10 + i * 8;
			ctx.fill(x + 7, ly, x + 29, ly + 2, 0xFF8FA3C9);
			int kx = x + 9 + ((i * 7) % 14);
			ctx.fill(kx, ly - 2, kx + 5, ly + 4, 0xFFFFFFFF);
		}

		// name + blue "Client" tag
		ctx.drawTextWithShadow(textRenderer, m.name, x + 38, y + 6, 0xFFFFFFFF);
		int tagX = x + 38 + textRenderer.getWidth(m.name) + 6;
		int tagW = textRenderer.getWidth("Client") + 8;
		ctx.fill(tagX, y + 4, tagX + tagW, y + 17, 0xFF1E3A66);
		ctx.drawTextWithShadow(textRenderer, "Client", tagX + 4, y + 6, 0xFF9CC3FF);

		// description
		String desc = textRenderer.trimToWidth(m.description, W - 38 - 50);
		ctx.drawTextWithShadow(textRenderer, desc, x + 38, y + 21, 0xFF8A8A8A);

		// on / off
		boolean on = m.isEnabled();
		String state = on ? "ON" : "OFF";
		ctx.drawTextWithShadow(textRenderer, state, x + W - 8 - textRenderer.getWidth(state), y + 14,
				on ? 0xFF55FF55 : 0xFFFF5555);
	}
}
