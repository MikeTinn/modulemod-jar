package com.modulesmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ModuleSettingsScreen extends Screen {
	private static final int W = 380;
	private static final int ROW_H = 32;

	private final Screen parent;
	private final Module module;
	private final List<Object> snapshot = new ArrayList<>();
	private final List<Entry> entries = new ArrayList<>();
	private String query = "";

	private record Entry(Setting setting, int y) {}

	public ModuleSettingsScreen(Screen parent, Module module) {
		super(Text.literal(module.name));
		this.parent = parent;
		this.module = module;
		for (Setting s : module.settings) snapshot.add(s.snapshot());
	}

	@Override
	protected void init() {
		entries.clear();
		int left = (width - W) / 2;

		TextFieldWidget search = new TextFieldWidget(textRenderer, left, 16, W, 20, Text.literal("Search"));
		search.setPlaceholder(Text.literal("Search..."));
		search.setText(query);
		search.setChangedListener(s -> {
			query = s;
			clearAndInit();
		});
		addDrawableChild(search);

		int controlX = left + W - 50 - 5 - 145;
		int resetX = left + W - 50;

		int y = 46;
		for (Setting s : module.settings) {
			if (!query.isEmpty() && !s.label.toLowerCase().contains(query.toLowerCase())) continue;

			switch (s.type) {
				case BOOL -> addDrawableChild(ButtonWidget.builder(boolText(s), b -> {
					s.bool = !s.bool;
					b.setMessage(boolText(s));
				}).dimensions(controlX, y, 145, 20).build());

				case INT -> {
					TextFieldWidget f = new TextFieldWidget(textRenderer, controlX, y, 145, 20, Text.literal(s.label));
					f.setTextPredicate(t -> t.matches("-?\\d{0,9}"));
					f.setText(String.valueOf((int) s.num));
					f.setChangedListener(t -> {
						try {
							s.num = Integer.parseInt(t);
						} catch (NumberFormatException ignored) {
						}
					});
					addDrawableChild(f);
				}

				case SLIDER -> addDrawableChild(new SettingSlider(controlX, y, 145, 20, s));
			}

			addDrawableChild(ButtonWidget.builder(Text.literal("Reset"), b -> {
				s.reset();
				clearAndInit();
			}).dimensions(resetX, y, 50, 20).build());

			entries.add(new Entry(s, y));
			y += ROW_H;
		}

		addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close())
				.dimensions(width / 2 - 155, height - 28, 150, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Save & Quit"), b -> {
			Modules.save();
			client.setScreen(parent);
		}).dimensions(width / 2 + 5, height - 28, 150, 20).build());
	}

	private static Text boolText(Setting s) {
		return Text.literal(s.bool ? "Yes" : "No").formatted(s.bool ? Formatting.GREEN : Formatting.RED);
	}

	/** Close = Cancel: throw away unsaved changes. */
	@Override
	public void close() {
		for (int i = 0; i < module.settings.size(); i++) {
			module.settings.get(i).restore(snapshot.get(i));
		}
		client.setScreen(parent);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		ctx.drawTextWithShadow(textRenderer, module.name, (width - textRenderer.getWidth(module.name)) / 2, 4, 0xFFFFFFFF);

		int left = (width - W) / 2;
		for (Entry e : entries) {
			ctx.drawTextWithShadow(textRenderer, e.setting().label, left, e.y() + 6, 0xFFFFFFFF);
		}
	}

	private static class SettingSlider extends SliderWidget {
		private final Setting s;

		SettingSlider(int x, int y, int w, int h, Setting s) {
			super(x, y, w, h, Text.empty(), (s.num - s.min) / (s.max - s.min));
			this.s = s;
			updateMessage();
		}

		@Override
		protected void updateMessage() {
			if (s == null) return;
			setMessage(Text.literal("Value: " + String.format(Locale.ROOT, "%.2f", s.num)));
		}

		@Override
		protected void applyValue() {
			s.num = Math.round((s.min + value * (s.max - s.min)) * 100.0) / 100.0;
		}
	}
}
