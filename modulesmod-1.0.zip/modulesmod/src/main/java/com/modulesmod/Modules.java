package com.modulesmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Modules {
	public static final Module SCOREBOARD = new Module("scoreboard", "Scoreboard",
			"Customize the sidebar scoreboard.",
			Setting.bool("hideNumbers", "Hide Red Numbers", false));

	public static final Module TAB = new Module("tab", "Tab",
			"Customize the player list shown when holding Tab.",
			Setting.integer("maxPlayers", "Max Players Shown", 80));

	public static final Module ASPECT_RATIO = new Module("aspect_ratio", "Aspect Ratio",
			"Stretch or squash the game's aspect ratio.",
			Setting.slider("ratio", "Aspect Ratio", 0.5, 3.0, 1.78));

	public static final Module CHAT = new Module("chat", "Chat",
			"Customize the chat window.",
			Setting.integer("historyLines", "Chat History Lines", 100));

	public static final Module HITBOX = new Module("hitbox", "Hitbox",
			"Customize entity hitboxes.",
			Setting.slider("expand", "Hitbox Expand", 0.0, 1.0, 0.0));

	public static final List<Module> ALL = List.of(SCOREBOARD, TAB, ASPECT_RATIO, CHAT, HITBOX);

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private Modules() {}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("modulesmod.json");
	}

	public static void load() {
		Path f = file();
		if (!Files.exists(f)) return;
		try (Reader r = Files.newBufferedReader(f)) {
			Map<String, Object> map = GSON.fromJson(r, new TypeToken<Map<String, Object>>() {}.getType());
			if (map == null) return;
			for (Module m : ALL) {
				for (Setting s : m.settings) {
					Object v = map.get(m.id + "." + s.id);
					if (s.type == Setting.Type.BOOL && v instanceof Boolean b) s.bool = b;
					else if (s.type != Setting.Type.BOOL && v instanceof Number n) s.num = n.doubleValue();
				}
			}
		} catch (Exception e) {
			ModulesMod.LOGGER.warn("Could not load config", e);
		}
	}

	public static void save() {
		Map<String, Object> map = new LinkedHashMap<>();
		for (Module m : ALL) {
			for (Setting s : m.settings) {
				map.put(m.id + "." + s.id, s.snapshot());
			}
		}
		try (Writer w = Files.newBufferedWriter(file())) {
			GSON.toJson(map, w);
		} catch (Exception e) {
			ModulesMod.LOGGER.warn("Could not save config", e);
		}
	}
}
