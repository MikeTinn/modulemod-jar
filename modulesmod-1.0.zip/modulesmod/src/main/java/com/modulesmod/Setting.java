package com.modulesmod;

public class Setting {
	public enum Type { BOOL, INT, SLIDER }

	public final String id;
	public final String label;
	public final Type type;
	public final double min;
	public final double max;
	private final boolean defBool;
	private final double defNum;

	public boolean bool;
	public double num;

	private Setting(String id, String label, Type type, double min, double max, boolean defBool, double defNum) {
		this.id = id;
		this.label = label;
		this.type = type;
		this.min = min;
		this.max = max;
		this.defBool = defBool;
		this.defNum = defNum;
		this.bool = defBool;
		this.num = defNum;
	}

	public static Setting bool(String id, String label, boolean def) {
		return new Setting(id, label, Type.BOOL, 0, 1, def, 0);
	}

	public static Setting integer(String id, String label, int def) {
		return new Setting(id, label, Type.INT, Integer.MIN_VALUE, Integer.MAX_VALUE, false, def);
	}

	public static Setting slider(String id, String label, double min, double max, double def) {
		return new Setting(id, label, Type.SLIDER, min, max, false, def);
	}

	public void reset() {
		bool = defBool;
		num = defNum;
	}

	public Object snapshot() {
		return type == Type.BOOL ? (Object) bool : (Object) num;
	}

	public void restore(Object o) {
		if (o instanceof Boolean b) bool = b;
		else if (o instanceof Number n) num = n.doubleValue();
	}
}
