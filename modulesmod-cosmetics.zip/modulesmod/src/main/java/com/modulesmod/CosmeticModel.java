package com.modulesmod;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;

/**
 * One cosmetic as a model. The root part follows the head or the torso of the player (including
 * sneaking), and the cosmetic's own parts animate: wings flap, capes sway, pets bob.
 * All the posing happens in setAngles(), because the game may call that later than we submit the model.
 */
public final class CosmeticModel extends EntityModel<PlayerEntityRenderState> {
	private static final float RAD = (float) (Math.PI / 180.0);

	private final Cosmetics.Def def;
	private float headYaw;
	private float headPitch;
	private float age;
	private boolean sneaking;

	CosmeticModel(ModelPart root, Cosmetics.Def def) {
		super(root);
		this.def = def;
	}

	/** Called right before the model is submitted for drawing. */
	void setPose(float headYawDeg, float headPitchDeg, boolean sneaking, float age) {
		this.headYaw = headYawDeg;
		this.headPitch = headPitchDeg;
		this.sneaking = sneaking;
		this.age = age;
	}

	@Override
	public void setAngles(PlayerEntityRenderState state) {
		super.setAngles(state);

		if ("HEAD".equals(def.attach())) {
			root.setOrigin(0f, sneaking ? 4.2f : 0f, 0f);
			root.setAngles(headPitch * RAD, headYaw * RAD, 0f);
		} else {
			root.setOrigin(0f, sneaking ? 3.2f : 0f, 0f);
			root.setAngles(sneaking ? 0.5f : 0f, 0f, 0f);
		}

		for (Cosmetics.PartDef p : def.parts()) {
			ModelPart part = root.getChild(p.name());
			part.pitch = p.rot()[0];
			part.yaw = p.rot()[1];
			part.roll = p.rot()[2];
			part.setOrigin(p.pivot()[0], p.pivot()[1], p.pivot()[2]);

			switch (def.anim()) {
				case "flap" -> {
					float flap = (float) Math.sin(age * 0.18f) * 0.22f * def.amp();
					if (p.name().equals("right")) part.yaw = p.rot()[1] + flap;
					else if (p.name().equals("left")) part.yaw = p.rot()[1] - flap;
				}
				case "sway" -> {
					if (p.name().equals("cape")) {
						part.pitch = p.rot()[0] + 0.06f * (float) Math.sin(age * 0.09f) + (sneaking ? 0.25f : 0f);
					}
				}
				case "bob" -> part.setOrigin(p.pivot()[0],
						p.pivot()[1] + (float) Math.sin(age * 0.12f) * def.amp(), p.pivot()[2]);
				default -> {
				}
			}
		}
	}
}
