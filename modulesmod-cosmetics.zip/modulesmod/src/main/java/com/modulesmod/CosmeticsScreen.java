package com.modulesmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Pick cosmetics by category and see them on your player. Click a card to equip it (click again to
 * take it off). The preview is your real player model, so it shows exactly what the game draws.
 */
public class CosmeticsScreen extends Screen {
	private static final int TAB_W = 80;
	private static final int TAB_H = 20;
	private static final int CARD_W = 84;
	private static final int CARD_H = 46;
	private static final int GAP = 6;
	private static final int PREVIEW_W = 150;
	private static final int TOTAL_W = TAB_W + 8 + CARD_W * 2 + GAP + 12 + PREVIEW_W;
	private static final int TOP = 40;

	private final Screen parent;
	private Cosmetics.Category tab = Cosmetics.Category.CAPE;
	/** -2..2: turns the preview a bit left or right (0 = it follows your mouse). */
	private int turn = 0;

	public CosmeticsScreen(Screen parent) {
		super(Text.literal("Cosmetics"));
		this.parent = parent;
	}

	private int left() {
		return (width - TOTAL_W) / 2;
	}

	private int cardsX() {
		return left() + TAB_W + 8;
	}

	private int previewX() {
		return cardsX() + CARD_W * 2 + GAP + 12;
	}

	private int bottom() {
		return height - 36;
	}

	@Override
	protected void init() {
		int px = previewX();
		int by = bottom() - 20;
		addDrawableChild(ButtonWidget.builder(Text.literal("\u25C0"), b -> turn = Math.max(-2, turn - 1))
				.dimensions(px, by, 30, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Mouse"), b -> turn = 0)
				.dimensions(px + 34, by, PREVIEW_W - 68, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("\u25B6"), b -> turn = Math.min(2, turn + 1))
				.dimensions(px + PREVIEW_W - 30, by, 30, 20).build());

		addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
				.dimensions(width / 2 - 100, height - 28, 200, 20).build());
	}

	@Override
	public void close() {
		client.setScreen(parent);
	}

	// ------------------------------------------------------------------ input

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (click.button() == 0) {
			double mx = click.x();
			double my = click.y();

			Cosmetics.Category[] tabs = Cosmetics.Category.values();
			for (int i = 0; i < tabs.length; i++) {
				if (inside(mx, my, left(), TOP + i * (TAB_H + 2), TAB_W, TAB_H)) {
					tab = tabs[i];
					return true;
				}
			}

			if (tab != Cosmetics.Category.TOOL) {
				List<Cosmetics.Def> items = Cosmetics.in(tab);
				// card 0 is "None", the rest are the cosmetics
				for (int i = 0; i <= items.size(); i++) {
					if (!inside(mx, my, cardX(i), cardY(i), CARD_W, CARD_H)) continue;
					if (i == 0) {
						Cosmetics.select(tab, null);
					} else {
						Cosmetics.Def d = items.get(i - 1);
						boolean already = d.id().equals(Cosmetics.selectedId(tab));
						Cosmetics.select(tab, already ? null : d.id());
					}
					return true;
				}
			}
		}
		return super.mouseClicked(click, doubled);
	}

	private static boolean inside(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	private int cardX(int index) {
		return cardsX() + (index % 2) * (CARD_W + GAP);
	}

	private int cardY(int index) {
		return TOP + (index / 2) * (CARD_H + GAP);
	}

	// ------------------------------------------------------------------ drawing

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		ctx.drawTextWithShadow(textRenderer, "Cosmetics", (width - textRenderer.getWidth("Cosmetics")) / 2, 8, 0xFFFFFFFF);
		String sub = "Only you can see these";
		ctx.drawTextWithShadow(textRenderer, sub, (width - textRenderer.getWidth(sub)) / 2, 20, 0xFF888888);

		drawTabs(ctx, mouseX, mouseY);
		drawCards(ctx, mouseX, mouseY);
		drawPreview(ctx, mouseX, mouseY);
	}

	private void drawTabs(DrawContext ctx, int mouseX, int mouseY) {
		Cosmetics.Category[] tabs = Cosmetics.Category.values();
		for (int i = 0; i < tabs.length; i++) {
			int x = left();
			int y = TOP + i * (TAB_H + 2);
			boolean on = tabs[i] == tab;
			boolean hover = inside(mouseX, mouseY, x, y, TAB_W, TAB_H);
			ctx.fill(x, y, x + TAB_W, y + TAB_H, on ? 0xCC2A2A44 : (hover ? 0xAA1E1E2C : 0x99101018));
			if (on) ctx.fill(x, y, x + 2, y + TAB_H, 0xFFFF7AA8);
			ctx.drawTextWithShadow(textRenderer, tabs[i].label, x + 8, y + 6, on ? 0xFFFFFFFF : 0xFFAAAAAA);
		}
	}

	private void drawCards(DrawContext ctx, int mouseX, int mouseY) {
		if (tab == Cosmetics.Category.TOOL) {
			int x = cardsX();
			ctx.drawTextWithShadow(textRenderer, "Tools", x, TOP, 0xFFFFFFFF);
			String[] lines = {"Custom sword and tool skins", "are coming next.", "", "Capes, wings, hats, jackets", "and pets work already."};
			for (int i = 0; i < lines.length; i++) {
				ctx.drawTextWithShadow(textRenderer, lines[i], x, TOP + 16 + i * 11, 0xFF9A9A9A);
			}
			return;
		}

		List<Cosmetics.Def> items = Cosmetics.in(tab);
		String current = Cosmetics.selectedId(tab);
		for (int i = 0; i <= items.size(); i++) {
			int x = cardX(i);
			int y = cardY(i);
			Cosmetics.Def d = i == 0 ? null : items.get(i - 1);
			boolean equipped = d == null ? current == null : d.id().equals(current);
			boolean hover = inside(mouseX, mouseY, x, y, CARD_W, CARD_H);

			ctx.fill(x, y, x + CARD_W, y + CARD_H, hover ? 0xCC20202E : 0xAA101018);
			int border = equipped ? (d == null ? 0xFF888888 : d.accent()) : 0x55FFFFFF;
			outline(ctx, x, y, x + CARD_W, y + CARD_H, border);

			if (d == null) {
				ctx.drawTextWithShadow(textRenderer, "None", x + 8, y + 8, 0xFFFFFFFF);
				ctx.drawTextWithShadow(textRenderer, equipped ? "Equipped" : "Take it off", x + 8, y + 24,
						equipped ? 0xFF7BE06A : 0xFF8A8A8A);
			} else {
				ctx.fill(x + 6, y + 6, x + 24, y + 24, d.accent());
				outline(ctx, x + 6, y + 6, x + 24, y + 24, 0xAA000000);
				String name = textRenderer.trimToWidth(d.name(), CARD_W - 32);
				ctx.drawTextWithShadow(textRenderer, name, x + 28, y + 11, 0xFFFFFFFF);
				ctx.drawTextWithShadow(textRenderer, equipped ? "Equipped" : "Click to equip", x + 8, y + 30,
						equipped ? 0xFF7BE06A : 0xFF8A8A8A);
			}
		}
	}

	private void drawPreview(DrawContext ctx, int mouseX, int mouseY) {
		int px = previewX();
		int py = TOP;
		int pw = PREVIEW_W;
		int ph = bottom() - 24 - TOP;
		ctx.fill(px, py, px + pw, py + ph, 0x99101018);
		outline(ctx, px, py, px + pw, py + ph, 0x55FFFFFF);

		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) {
			String msg = "Join a world to preview";
			ctx.drawTextWithShadow(textRenderer, msg, px + (pw - textRenderer.getWidth(msg)) / 2, py + ph / 2, 0xFF9A9A9A);
			return;
		}

		float cx = px + pw / 2f;
		float fakeX = turn == 0 ? mouseX : cx - turn * 45f;
		float fakeY = turn == 0 ? mouseY : py + ph * 0.35f;
		int size = (int) (ph * 0.4f);
		InventoryScreen.drawEntity(ctx, px + 2, py + 2, px + pw - 2, py + ph - 2, size, 0.0625f, fakeX, fakeY, mc.player);
	}

	private static void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
		ctx.fill(x1, y1, x2, y1 + 1, color);
		ctx.fill(x1, y2 - 1, x2, y2, color);
		ctx.fill(x1, y1, x1 + 1, y2, color);
		ctx.fill(x2 - 1, y1, x2, y2, color);
	}
}
