# Modules Mod (Fabric 1.21.11)

Client-side mod with 5 modules: Scoreboard, Tab, Aspect Ratio, Chat, Hitbox.
Open the settings from Mod Menu (Mods -> Modules Mod -> Configure button).

Working modules: Scoreboard, Tab, Aspect Ratio, Chat (also /chatsearch), Hitbox, Armor Status, Block Outline, Fog Customizer. Motion Blur, Weather Changer, FPS, Reach, Ping and Inventory HUD are on/off only for now. Run /modulesmod status in game to see which hooks are running.
Settings are saved to config/modulesmod.json.

Build: push to GitHub, Actions tab -> Build -> download the jar artifact.
