package com.modulesmod;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

public class ModuleListScreen extends Screen {
	private static final int W = 360;
	private static final int ROW_H = 36;
	private static final int GAP = 4;
	private static final int TOP = 46;
	private static final int TOGGLE_W = 36;

	private final Screen parent;
	private String query = "";
	private TextFieldWidget search;
	private final List<Row> rows = new ArrayList<>();
	private final ScrollBar scrollBar = new ScrollBar();
	private ButtonWidget upButton;
	private ButtonWidget downButton;
	private int scroll = 0;
	private int maxScroll = 0;

	private static class Row {
		final Module module;
		final ButtonWidget button;
		final ButtonWidget toggle;
		int y;

		Row(Module module, ButtonWidget button, ButtonWidget toggle) {
			this.module = module;
			this.button = button;
			this.toggle = toggle;
		}
	}

	public ModuleListScreen(Screen parent) {
		super(Text.literal("Modules"));
		this.parent = parent;
	}

	private static Text stateText(Module m) {
		boolean on = m.isEnabled();
		return Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED);
	}

	private int bottom() {
		return height - 34;
	}

	private int contentH() {
		return rows.size() * (ROW_H + GAP);
	}

	private int barX() {
		return (width - W) / 2 + W + 8;
	}

	@Override
	protected void init() {
		rows.clear();
		int left = (width - W) / 2;

		search = new TextFieldWidget(textRenderer, left, 16, W - 152, 20, Text.literal("Search"));
		search.setPlaceholder(Text.literal("Search..."));
		search.setText(query);
		search.setChangedListener(s -> {
			query = s;
			clearAndInit();
		});
		addDrawableChild(search);
		setInitialFocus(search);

		// the cosmetics screen: capes, wings, hats, jackets, pets
		addDrawableChild(ButtonWidget.builder(Text.literal("Cosmetics"), b -> client.setScreen(new CosmeticsScreen(this)))
				.dimensions(left + W - 148, 16, 74, 20).build());

		// opens the HUD editor, where you drag the HUDs to where you want them
		addDrawableChild(ButtonWidget.builder(Text.literal("Move HUDs"), b -> client.setScreen(new HudEditorScreen(this)))
				.dimensions(left + W - 70, 16, 70, 20).build());

		for (Module m : Modules.ALL) {
			if (!query.isEmpty() && !m.name.toLowerCase().contains(query.toLowerCase())) continue;

			ButtonWidget button = ButtonWidget.builder(Text.empty(),
					b -> client.setScreen(new ModuleSettingsScreen(this, m)))
					.dimensions(left, 0, W - TOGGLE_W - 6, ROW_H).build();
			addDrawableChild(button);

			// quick on/off without opening the module
			ButtonWidget toggle = ButtonWidget.builder(stateText(m), b -> {
				Setting enabled = m.settings.get(0);
				enabled.bool = !enabled.bool;
				b.setMessage(stateText(m));
				Modules.save();
			}).dimensions(left + W - TOGGLE_W, 0, TOGGLE_W, 20).build();
			addDrawableChild(toggle);

			rows.add(new Row(m, button, toggle));
		}

		addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
				.dimensions(width / 2 - 100, height - 28, 200, 20).build());

		upButton = ButtonWidget.builder(Text.literal("\u25B2"), b -> scrollBy(-(ROW_H + GAP)))
				.dimensions(barX() - 4, 18, 14, 14).build();
		downButton = ButtonWidget.builder(Text.literal("\u25BC"), b -> scrollBy(ROW_H + GAP))
				.dimensions(barX() - 4, bottom() + 4, 14, 14).build();
		addDrawableChild(upButton);
		addDrawableChild(downButton);

		layout();
	}

	private void scrollBy(int delta) {
		scroll = Math.max(0, Math.min(maxScroll, scroll + delta));
		layout();
	}

	private void layout() {
		int bottom = bottom();
		int viewH = bottom - TOP;
		maxScroll = Math.max(0, contentH() - viewH);
		scroll = Math.max(0, Math.min(maxScroll, scroll));

		for (int i = 0; i < rows.size(); i++) {
			Row r = rows.get(i);
			int y = TOP + i * (ROW_H + GAP) - scroll;
			boolean vis = y >= TOP - 2 && y + ROW_H <= bottom;
			r.y = y;
			r.button.setY(y);
			r.button.visible = vis;
			r.button.active = vis;
			r.toggle.setY(y + (ROW_H - 20) / 2);
			r.toggle.visible = vis;
			r.toggle.active = vis;
		}

		boolean arrows = maxScroll > 0;
		if (upButton != null) {
			upButton.visible = arrows;
			upButton.active = arrows;
			downButton.visible = arrows;
			downButton.active = arrows;
		}
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		if (maxScroll > 0) {
			scrollBy(-(int) (verticalAmount * 14));
			return true;
		}
		return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (maxScroll > 0 && click.button() == 0
				&& scrollBar.press(click.x(), click.y(), scroll, maxScroll, barX(), TOP, bottom(), contentH())) {
			scroll = scrollBar.drag(click.y(), maxScroll, TOP, bottom(), contentH());
			layout();
			return true;
		}
		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(Click click, double offsetX, double offsetY) {
		if (scrollBar.isDragging()) {
			scroll = scrollBar.drag(click.y(), maxScroll, TOP, bottom(), contentH());
			layout();
			return true;
		}
		return super.mouseDragged(click, offsetX, offsetY);
	}

	@Override
	public boolean mouseReleased(Click click) {
		scrollBar.release();
		return super.mouseReleased(click);
	}

	@Override
	public void close() {
		client.setScreen(parent);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		ctx.drawTextWithShadow(textRenderer, "Modules", (width - textRenderer.getWidth("Modules")) / 2, 4, 0xFFFFFFFF);

		int bottom = bottom();
		for (Row r : rows) {
			if (r.y >= TOP - 2 && r.y + ROW_H <= bottom) drawRow(ctx, r);
		}

		if (rows.isEmpty()) {
			String msg = "No modules found";
			ctx.drawTextWithShadow(textRenderer, msg, (width - textRenderer.getWidth(msg)) / 2, 60, 0xFFAAAAAA);
		}

		if (maxScroll > 0) {
			scrollBar.draw(ctx, barX(), TOP, bottom, contentH(), scroll, maxScroll);
		}
	}

	private void drawRow(DrawContext ctx, Row r) {
		Module m = r.module;
		int x = r.button.getX();
		int y = r.button.getY();
		boolean on = m.isEnabled();

		ModuleIcons.draw(ctx, m.id, x + 4, y + 4, on);

		ctx.drawTextWithShadow(textRenderer, m.name, x + 38, y + 7, on ? 0xFFFFFFFF : 0xFF888888);
		String desc = textRenderer.trimToWidth(m.description, W - TOGGLE_W - 6 - 38 - 8);
		ctx.drawTextWithShadow(textRenderer, desc, x + 38, y + 21, 0xFF8A8A8A);
	}
}
