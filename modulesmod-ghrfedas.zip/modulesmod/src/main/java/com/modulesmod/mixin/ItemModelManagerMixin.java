package com.modulesmod.mixin;

import com.modulesmod.ToolSkins;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Lets Cosmetics swap the model of the tool in your hand. Optional mixin config: if it fails, only tool skins stop working. */
@Mixin(ItemModelManager.class)
public abstract class ItemModelManagerMixin {
	@ModifyVariable(method = {"update", "clearAndUpdate"}, at = @At("HEAD"), argsOnly = true, require = 0)
	private ItemStack modulesmod$toolSkin(ItemStack stack) {
		return ToolSkins.apply(stack);
	}
}
