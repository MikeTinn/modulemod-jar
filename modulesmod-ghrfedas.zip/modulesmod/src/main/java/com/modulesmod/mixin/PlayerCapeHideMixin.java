package com.modulesmod.mixin;

import com.modulesmod.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides your own real cape while the Cosmetics module is on, so your cosmetic cape is the only one. */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerCapeHideMixin {
	@Inject(method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
			at = @At("TAIL"), require = 0)
	private void modulesmod$hideOwnCape(AbstractClientPlayerEntity player, PlayerEntityRenderState state,
										float tickProgress, CallbackInfo ci) {
		if (!Modules.COSMETICS.isEnabled() || !Modules.CO_HIDE_CAPE.bool) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player != null && player == mc.player) state.capeVisible = false;
	}
}
