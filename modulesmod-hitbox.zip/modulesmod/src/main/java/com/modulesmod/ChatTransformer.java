package com.modulesmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.text.MutableText;
import net.minecraft.text.ObjectTextContent;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.text.object.PlayerTextObjectContents;
import net.minecraft.util.Identifier;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Everything the Chat module does to a message before it is added to the chat window:
 * heads, timestamps, emoji, name highlight, font, shadow, colour. The vanilla chat window
 * (scrolling, clicking, hovering) is left alone, so all of that keeps working.
 */
public final class ChatTransformer {
	// index matches Modules.CH_FONT options; null = vanilla default font
	private static final Identifier[] FONTS = {
			null,
			Identifier.of("minecraft", "uniform"),
			Identifier.of("minecraft", "alt"),
			Identifier.of("minecraft", "illageralt")
	};

	private static final Pattern NAME_TOKEN = Pattern.compile("[A-Za-z0-9_]{1,16}");

	private ChatTransformer() {}

	/** Called by ChatHudMixin for every message that is added. Never throws. */
	public static Text transform(Text original) {
		if (!Modules.CHAT.isEnabled()) return original;
		try {
			return doTransform(original);
		} catch (Exception e) {
			ModulesMod.LOGGER.warn("Chat transform failed", e);
			return original;
		}
	}

	public static int maxLines(int vanilla) {
		if (!Modules.CHAT.isEnabled()) return vanilla;
		return Math.max(100, Math.min(100000, (int) Modules.CH_HISTORY.num));
	}

	public static double sizeMultiplier() {
		return Modules.CHAT.isEnabled() ? Modules.CH_SIZE.num : 1.0;
	}

	private static Text doTransform(Text original) {
		MinecraftClient mc = MinecraftClient.getInstance();
		String plain = original.getString();
		ChatState.record(original, plain);

		// ---- stacking: the same message again in a row becomes "message (x2)" ----
		int stackCount = 1;
		if (Modules.CH_STACK.bool && !plain.isBlank() && plain.equals(ChatState.lastPlain)) {
			stackCount = ChatState.lastCount + 1;
			ChatState.stackRemove = ChatState.lastVisibleLines;
		} else {
			ChatState.stackRemove = 0;
		}
		ChatState.lastPlain = plain;
		ChatState.lastCount = stackCount;

		ClientPlayNetworkHandler nh = mc.getNetworkHandler();
		boolean wantHead = Modules.CH_HEADS.bool;
		PlayerListEntry sender = wantHead || Modules.CH_MENTION.bool ? findSender(nh, plain) : null;
		PlayerListEntry own = (nh != null && mc.player != null) ? nh.getPlayerListEntry(mc.player.getUuid()) : null;
		boolean fromMe = sender != null && sender == own;

		// ---- emoji + name highlight (rebuilds the text but keeps every click / hover / colour) ----
		String me = mc.player == null ? null : mc.player.getName().getString();
		boolean emoji = Modules.CH_EMOJI_IN.bool;
		boolean mention = Modules.CH_MENTION.bool && me != null && !fromMe
				&& plain.toLowerCase(Locale.ROOT).contains(me.toLowerCase(Locale.ROOT));

		Text body = original;
		if (emoji || mention) {
			final int mentionRgb = HudUtil.rgb(Modules.CH_MENTION_COLOR.str, 0xFFFF55);
			final boolean mentionBold = Modules.CH_MENTION_BOLD.bool;
			final boolean faces = Modules.CH_FACES.bool;
			final String key = mention ? me : null;
			MutableText out = Text.empty();
			original.<Object>visit((style, str) -> {
				String s = emoji ? Emojis.replace(str, faces) : str;
				if (key == null) {
					out.append(Text.literal(s).setStyle(style));
				} else {
					appendHighlighted(out, style, s, key, mentionRgb, mentionBold);
				}
				return Optional.empty();
			}, Style.EMPTY);
			body = out;
		}

		// ---- assemble: [time] [head] message ----
		MutableText result = Text.empty();
		if (Modules.CH_TIME.bool) result.append(timestamp());
		if (wantHead && sender != null) {
			result.append(head(sender));
			result.append(Text.literal(" "));
		}
		result.append(body);
		if (stackCount > 1) {
			result.append(Text.literal(" (x" + stackCount + ")")
					.setStyle(Style.EMPTY.withColor(HudUtil.rgb(Modules.CH_STACK_COLOR.str, 0xAAAAAA))));
		}

		// ---- font / shadow / colour for the whole message ----
		final int fontIdx = Modules.CH_FONT.index();
		final boolean shadowOff = !Modules.CH_SHADOW.bool;
		final boolean colorOn = Modules.CH_COLOR_ON.bool;
		final int colorRgb = HudUtil.rgb(Modules.CH_COLOR.str, 0xFFFFFF);
		if (fontIdx > 0 || shadowOff || colorOn) {
			result.styled(s -> {
				if (fontIdx > 0 && fontIdx < FONTS.length) s = s.withFont(new StyleSpriteSource.Font(FONTS[fontIdx]));
				if (shadowOff) s = s.withShadowColor(0x00000000);
				if (colorOn) s = s.withColor(colorRgb);
				return s;
			});
		}

		// rough line count so Smooth Chat knows how far to slide
		int width = mc.textRenderer.getWidth(result);
		double size = Modules.CH_SIZE.num <= 0 ? 1.0 : Modules.CH_SIZE.num;
		ChatState.added((int) Math.ceil(width * size / 320.0));

		return result;
	}

	private static Text timestamp() {
		String pattern = Modules.CH_TIME_FMT.index() == 1 ? "hh:mm a" : "HH:mm";
		String t = LocalTime.now().format(DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH));
		return Text.literal("[" + t + "] ")
				.setStyle(Style.EMPTY.withColor(HudUtil.rgb(Modules.CH_TIME_COLOR.str, 0xAAAAAA)));
	}

	private static Text head(PlayerListEntry sender) {
		return MutableText.of(new ObjectTextContent(
				new PlayerTextObjectContents(ProfileComponent.ofStatic(sender.getProfile()), Modules.CH_HEAD_HAT.bool)));
	}

	/**
	 * Finds who sent a message: the last player name that appears before the first ':' or '>'
	 * ("<Steve> hi", "[VIP] Steve: hi"). Messages with no such separator (join / leave / system) get no head.
	 */
	private static PlayerListEntry findSender(ClientPlayNetworkHandler nh, String plain) {
		if (nh == null) return null;
		int delim = -1;
		for (int i = 0; i < Math.min(plain.length(), 45); i++) {
			char c = plain.charAt(i);
			if (c == ':' || c == '>' || c == '\u00BB') {
				delim = i;
				break;
			}
		}
		if (delim <= 0) return null;
		Matcher m = NAME_TOKEN.matcher(plain.substring(0, delim));
		PlayerListEntry found = null;
		while (m.find()) {
			PlayerListEntry e = nh.getPlayerListEntry(m.group());
			if (e != null) found = e;
		}
		return found;
	}

	/** Appends s to out, colouring every (case-insensitive) occurrence of key. */
	private static void appendHighlighted(MutableText out, Style style, String s, String key, int rgb, boolean bold) {
		String lower = s.toLowerCase(Locale.ROOT);
		String k = key.toLowerCase(Locale.ROOT);
		int from = 0;
		int idx;
		while (!k.isEmpty() && (idx = lower.indexOf(k, from)) >= 0) {
			if (idx > from) out.append(Text.literal(s.substring(from, idx)).setStyle(style));
			Style hs = style.withColor(rgb);
			if (bold) hs = hs.withBold(true);
			out.append(Text.literal(s.substring(idx, idx + k.length())).setStyle(hs));
			from = idx + k.length();
		}
		if (from < s.length()) out.append(Text.literal(s.substring(from)).setStyle(style));
	}

	/** Used by the search screen: yellow + bold on every match. */
	public static Text highlight(Text input, String query) {
		MutableText out = Text.empty();
		input.<Object>visit((style, str) -> {
			appendHighlighted(out, style, str, query, 0xFFFF55, true);
			return Optional.empty();
		}, Style.EMPTY);
		return out;
	}
}
