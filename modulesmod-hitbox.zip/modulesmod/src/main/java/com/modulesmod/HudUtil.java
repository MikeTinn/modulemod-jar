package com.modulesmod;

final class HudUtil {
	private HudUtil() {}

	/** "FF8800" -> 0xFF8800, falls back to def if the text isn't a 6 digit hex. */
	static int rgb(String hex, int def) {
		try {
			if (hex != null && hex.length() == 6) return Integer.parseInt(hex, 16);
		} catch (NumberFormatException ignored) {
		}
		return def;
	}

	/** 0-100 percent -> 0-255 alpha. */
	static int alpha(double percent) {
		return (int) Math.round(Math.max(0, Math.min(100, percent)) / 100.0 * 255.0);
	}
}
