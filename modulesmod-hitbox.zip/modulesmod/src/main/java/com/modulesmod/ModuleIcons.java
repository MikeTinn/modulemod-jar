package com.modulesmod;

import net.minecraft.client.gui.DrawContext;

/** Little pictograms for each module, drawn with plain rectangles (no image files needed). */
final class ModuleIcons {
	private static final int LIGHT = 0xFFDCE6FF;
	private static final int BG = 0xFF0B1226;

	private ModuleIcons() {}

	static int accent(String id) {
		return switch (id) {
			case "scoreboard" -> 0xFF5AA9FF;
			case "tab" -> 0xFF7CE38B;
			case "aspect_ratio" -> 0xFFFFB454;
			case "chat" -> 0xFFC792EA;
			case "hitbox" -> 0xFFFF6B6B;
			default -> 0xFF9CC3FF;
		};
	}

	private static int dim(int argb) {
		int r = ((argb >> 16) & 0xFF) / 2;
		int g = ((argb >> 8) & 0xFF) / 2;
		int b = (argb & 0xFF) / 2;
		return 0xFF000000 | (r << 16) | (g << 8) | b;
	}

	private static void outline(DrawContext c, int x1, int y1, int x2, int y2, int color) {
		c.fill(x1, y1, x2, y1 + 1, color);
		c.fill(x1, y2 - 1, x2, y2, color);
		c.fill(x1, y1, x1 + 1, y2, color);
		c.fill(x2 - 1, y1, x2, y2, color);
	}

	/** Draws a 28x28 icon with its top-left corner at (x, y). Dimmed when the module is off. */
	static void draw(DrawContext c, String id, int x, int y, boolean enabled) {
		int accent = enabled ? accent(id) : dim(accent(id));
		int light = enabled ? LIGHT : 0xFF707070;

		c.fill(x, y, x + 28, y + 28, BG);
		outline(c, x, y, x + 28, y + 28, (0x66 << 24) | (accent & 0xFFFFFF));

		switch (id) {
			case "scoreboard" -> {
				c.fill(x + 6, y + 6, x + 22, y + 9, accent);
				for (int i = 0; i < 3; i++) {
					int ry = y + 12 + i * 5;
					c.fill(x + 6, ry, x + 15, ry + 2, light);
					c.fill(x + 17, ry, x + 22, ry + 2, accent);
				}
			}
			case "tab" -> {
				for (int col = 0; col < 2; col++) {
					for (int row = 0; row < 3; row++) {
						int cx = x + 5 + col * 10;
						int cy = y + 6 + row * 6;
						c.fill(cx, cy, cx + 3, cy + 3, accent);
						c.fill(cx + 4, cy + 1, cx + 9, cy + 3, light);
					}
				}
			}
			case "aspect_ratio" -> {
				outline(c, x + 5, y + 8, x + 23, y + 20, accent);
				c.fill(x + 9, y + 13, x + 19, y + 15, light);
				c.fill(x + 8, y + 12, x + 10, y + 16, light);
				c.fill(x + 18, y + 12, x + 20, y + 16, light);
			}
			case "chat" -> {
				c.fill(x + 5, y + 6, x + 23, y + 18, accent);
				c.fill(x + 8, y + 18, x + 13, y + 20, accent);
				c.fill(x + 8, y + 20, x + 10, y + 22, accent);
				for (int i = 0; i < 3; i++) {
					c.fill(x + 9 + i * 4, y + 11, x + 11 + i * 4, y + 13, BG);
				}
			}
			case "hitbox" -> {
				outline(c, x + 7, y + 11, x + 19, y + 23, accent);
				outline(c, x + 11, y + 7, x + 23, y + 19, light);
				for (int i = 0; i < 4; i++) {
					c.fill(x + 7 + i, y + 11 - i, x + 8 + i, y + 12 - i, accent);
					c.fill(x + 18 + i, y + 22 - i, x + 19 + i, y + 23 - i, accent);
				}
				c.fill(x + 12, y + 16, x + 14, y + 18, light);
			}
			default -> c.fill(x + 8, y + 8, x + 20, y + 20, accent);
		}
	}
}
