package com.modulesmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Modules {
	// ---- Scoreboard settings ----
	public static final Setting SB_OPACITY = Setting.slider("opacity", "Background Opacity", 0, 100, 30, 0);
	public static final Setting SB_SCALE = Setting.slider("scale", "Scale", 0.5, 2.0, 1.0, 2);
	public static final Setting SB_HIDE_TITLE = Setting.bool("hideTitle", "Hide Title", false);
	public static final Setting SB_HIDE_NUMBERS = Setting.bool("hideNumbers", "Hide Scores (red numbers)", false);
	public static final Setting SB_HIDDEN_ROWS = Setting.text("hiddenRows", "Hide Rows (e.g. 1,3,5-7)", "");
	public static final Setting SB_HIDDEN_TEXT = Setting.text("hiddenText", "Hide Rows Containing", "");
	public static final Setting SB_FONT = Setting.choice("font", "Font", 0,
			"Default", "Uniform", "Alt (Enchanting)", "Illager");
	public static final Setting SB_COLOR = Setting.hex("textColor", "Text Color (hex)", "FFFFFF");
	public static final Setting SB_SHADOW = Setting.bool("shadow", "Text Shadow", false);
	public static final Setting SB_BOLD = Setting.bool("bold", "Bold", false);
	public static final Setting SB_ITALIC = Setting.bool("italic", "Italic", false);

	public static final Module SCOREBOARD = new Module("scoreboard", "Scoreboard",
			"Customize the sidebar scoreboard.",
			SB_OPACITY, SB_SCALE, SB_HIDE_TITLE, SB_HIDE_NUMBERS, SB_HIDDEN_ROWS, SB_HIDDEN_TEXT,
			SB_FONT, SB_COLOR, SB_SHADOW, SB_BOLD, SB_ITALIC);

	// ---- Tab settings ----
	public static final Setting T_SCALE = Setting.slider("scale", "Size", 0.5, 2.0, 1.0, 2);
	public static final Setting T_TEXT_COLOR = Setting.hex("textColor", "Text Color (hex)", "FFFFFF");
	public static final Setting T_BG_COLOR = Setting.hex("bgColor", "Background Color (hex)", "000000");
	public static final Setting T_OPACITY = Setting.slider("opacity", "Background Opacity", 0, 100, 50, 0);
	public static final Setting T_ROW_BG = Setting.bool("rowBg", "Row Backgrounds", true);
	public static final Setting T_HIDE_HEADER = Setting.bool("hideHeader", "Hide Header", false);
	public static final Setting T_HIDE_FOOTER = Setting.bool("hideFooter", "Hide Footer", false);
	public static final Setting T_MAX = Setting.integer("maxPlayers", "Max Players Shown", 80);
	public static final Setting T_HEADS = Setting.bool("heads", "Show Heads", true);
	public static final Setting T_SHADOW = Setting.bool("shadow", "Text Shadow", true);
	public static final Setting T_PING = Setting.choice("pingStyle", "Ping Style", 2, "Off", "Number", "Bars");
	public static final Setting T_PING_1 = Setting.hex("ping1", "Ping Color 0-50 ms", "55FF55");
	public static final Setting T_PING_2 = Setting.hex("ping2", "Ping Color 51-100 ms", "AAFF55");
	public static final Setting T_PING_3 = Setting.hex("ping3", "Ping Color 101-150 ms", "FFFF55");
	public static final Setting T_PING_4 = Setting.hex("ping4", "Ping Color 151-250 ms", "FFAA00");
	public static final Setting T_PING_5 = Setting.hex("ping5", "Ping Color 251+ ms", "FF5555");
	public static final Setting T_OWN = Setting.bool("ownHighlight", "Highlight Own Name", true);
	public static final Setting T_OWN_COLOR = Setting.hex("ownColor", "Own Name Color (hex)", "FFFF55");
	public static final Setting T_OWN_BOLD = Setting.bool("ownBold", "Own Name Bold", true);
	public static final Setting T_OWN_UL = Setting.bool("ownUnderline", "Own Name Underline", false);
	public static final Setting T_OWN_BG = Setting.bool("ownRowBg", "Own Row Highlight", true);

	public static final Module TAB = new Module("tab", "Tab",
			"Customize the player list shown when holding Tab.",
			T_SCALE, T_TEXT_COLOR, T_BG_COLOR, T_OPACITY, T_ROW_BG, T_HIDE_HEADER, T_HIDE_FOOTER,
			T_MAX, T_HEADS, T_SHADOW, T_PING, T_PING_1, T_PING_2, T_PING_3, T_PING_4, T_PING_5,
			T_OWN, T_OWN_COLOR, T_OWN_BOLD, T_OWN_UL, T_OWN_BG);

	// ---- Aspect Ratio settings ----
	public static final Setting AR_RATIO = Setting.slider("ratio", "Aspect Ratio", 0.5, 3.0, 1.78, 2);
	public static final Setting AR_PRESET = Setting.preset("preset", "Preset", AR_RATIO);
	public static final Setting AR_NAME = Setting.text("presetName", "New Preset Name", "");
	public static final Setting AR_SAVE = Setting.action("savePreset", "Save Preset", "Save Current Ratio", () -> {
		AspectPresets.saveUser(AR_NAME.str, AR_RATIO.num);
		AR_NAME.str = "";
	});
	public static final Setting AR_DELETE = Setting.action("deletePreset", "Delete Preset", "Delete Selected Preset",
			() -> AspectPresets.deleteMatching(AR_RATIO.num));

	public static final Module ASPECT_RATIO = new Module("aspect_ratio", "Aspect Ratio",
			"Make everything look wider or slimmer, with saveable presets.",
			AR_PRESET, AR_RATIO, AR_NAME, AR_SAVE, AR_DELETE);

	// ---- Chat settings ----
	public static final Setting CH_SMOOTH = Setting.bool("smooth", "Smooth Chat", true);
	public static final Setting CH_SMOOTH_MS = Setting.slider("smoothMs", "Smooth Speed (ms)", 50, 600, 250, 0);
	public static final Setting CH_SIZE = Setting.slider("size", "Size", 0.5, 2.0, 1.0, 2);
	public static final Setting CH_HISTORY = Setting.integer("historyLines", "Chat History Lines", 1000);
	public static final Setting CH_BG_ON = Setting.bool("customBg", "Custom Background", false);
	public static final Setting CH_BG = Setting.slider("bgOpacity", "Background Opacity", 0, 100, 50, 0);
	public static final Setting CH_FONT = Setting.choice("font", "Font", 0,
			"Default", "Uniform", "Alt (Enchanting)", "Illager");
	public static final Setting CH_SHADOW = Setting.bool("shadow", "Text Shadow", true);
	public static final Setting CH_COLOR_ON = Setting.bool("overrideColor", "Override Text Color", false);
	public static final Setting CH_COLOR = Setting.hex("textColor", "Text Color (hex)", "FFFFFF");
	public static final Setting CH_HEADS = Setting.bool("heads", "Chat Heads", true);
	public static final Setting CH_HEAD_HAT = Setting.bool("headHat", "Heads Show Hat Layer", true);
	public static final Setting CH_TIME = Setting.bool("timestamps", "Timestamps", false);
	public static final Setting CH_TIME_FMT = Setting.choice("timeFormat", "Time Format", 0, "24 hour", "12 hour");
	public static final Setting CH_TIME_COLOR = Setting.hex("timeColor", "Timestamp Color (hex)", "AAAAAA");
	public static final Setting CH_EMOJI = Setting.bool("emoji", "Emoji Shortcodes (send)", true);
	public static final Setting CH_EMOJI_IN = Setting.bool("emojiIncoming", "Convert Incoming Emojis", true);
	public static final Setting CH_FACES = Setting.bool("faces", "Text Faces (:) <3)", false);
	public static final Setting CH_MENTION = Setting.bool("mention", "Highlight My Name", true);
	public static final Setting CH_MENTION_COLOR = Setting.hex("mentionColor", "Mention Color (hex)", "FFFF55");
	public static final Setting CH_MENTION_BOLD = Setting.bool("mentionBold", "Mention Bold", true);
	public static final Setting CH_STACK = Setting.bool("stack", "Stack Duplicate Messages", true);
	public static final Setting CH_STACK_COLOR = Setting.hex("stackColor", "Stack Counter Color (hex)", "AAAAAA");
	public static final Setting CH_SEARCH = Setting.action("search", "Chat Search", "Open Search", () -> {
		net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
		mc.setScreen(new ChatSearchScreen(mc.currentScreen, ""));
	});
	public static final Setting CH_CLEAR_LOG = Setting.action("clearLog", "Search Log", "Clear Search Log",
			ChatState.LOG::clear);

	public static final Module CHAT = new Module("chat", "Chat",
			"Smooth chat, heads, search, emojis, longer history, font and more.",
			CH_SMOOTH, CH_SMOOTH_MS, CH_SIZE, CH_HISTORY, CH_BG_ON, CH_BG,
			CH_FONT, CH_SHADOW, CH_COLOR_ON, CH_COLOR,
			CH_HEADS, CH_HEAD_HAT, CH_TIME, CH_TIME_FMT, CH_TIME_COLOR,
			CH_STACK, CH_STACK_COLOR,
			CH_EMOJI, CH_EMOJI_IN, CH_FACES,
			CH_MENTION, CH_MENTION_COLOR, CH_MENTION_BOLD,
			CH_SEARCH, CH_CLEAR_LOG);

	// ---- Hitbox settings ----
	public static final Setting HB_COLOR = Setting.hex("color", "Hitbox Color (hex)", "FFFFFF");
	public static final Setting HB_AIM_COLOR = Setting.hex("aimColor", "Aim Color (hex)", "FF5555");
	public static final Setting HB_WIDTH = Setting.slider("width", "Line Width", 1.0, 8.0, 2.0, 1);
	public static final Setting HB_FILL = Setting.bool("fill", "Fill", false);
	public static final Setting HB_FILL_OPACITY = Setting.slider("fillOpacity", "Fill Opacity", 0, 100, 25, 0);

	public static final Module HITBOX = new Module("hitbox", "Hitbox",
			"Hitbox color, aim color, width and fill (settings only, not drawn in game yet).",
			HB_COLOR, HB_AIM_COLOR, HB_WIDTH, HB_FILL, HB_FILL_OPACITY);

	public static final List<Module> ALL = List.of(SCOREBOARD, TAB, ASPECT_RATIO, CHAT, HITBOX);

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private Modules() {}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("modulesmod.json");
	}

	public static void load() {
		Path f = file();
		if (!Files.exists(f)) return;
		try (Reader r = Files.newBufferedReader(f)) {
			Map<String, Object> map = GSON.fromJson(r, new TypeToken<Map<String, Object>>() {}.getType());
			if (map == null) return;
			for (Module m : ALL) {
				for (Setting s : m.settings) {
					Object v = map.get(m.id + "." + s.id);
					if (v == null) continue;
					switch (s.type) {
						case BOOL -> { if (v instanceof Boolean b) s.bool = b; }
						case TEXT, HEX -> { if (v instanceof String str) s.str = str; }
						default -> { if (v instanceof Number n) s.num = n.doubleValue(); }
					}
				}
			}
		} catch (Exception e) {
			ModulesMod.LOGGER.warn("Could not load config", e);
		}
	}

	public static void save() {
		Map<String, Object> map = new LinkedHashMap<>();
		for (Module m : ALL) {
			for (Setting s : m.settings) {
				if (s.type == Setting.Type.PRESET || s.type == Setting.Type.ACTION) continue;
				map.put(m.id + "." + s.id, s.snapshot());
			}
		}
		try (Writer w = Files.newBufferedWriter(file())) {
			GSON.toJson(map, w);
		} catch (Exception e) {
			ModulesMod.LOGGER.warn("Could not save config", e);
		}
	}
}
