package com.modulesmod;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ModulesMod implements ClientModInitializer {
	public static final String MOD_ID = "modulesmod";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitializeClient() {
		Modules.load();
		AspectPresets.load();
		ScoreboardHud.register();
		TabHud.register();

		// :heart: -> a symbol every player can see (only for chat messages, never commands)
		ClientSendMessageEvents.MODIFY_CHAT.register(message -> {
			if (!Modules.CHAT.isEnabled() || !Modules.CH_EMOJI.bool) return message;
			return Emojis.replace(message, Modules.CH_FACES.bool);
		});

		// /chatsearch [text]
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
				ClientCommandManager.literal("chatsearch")
						.executes(ctx -> {
							openSearch("");
							return 1;
						})
						.then(ClientCommandManager.argument("text", StringArgumentType.greedyString())
								.executes(ctx -> {
									openSearch(StringArgumentType.getString(ctx, "text"));
									return 1;
								}))));
	}

	private static void openSearch(String query) {
		MinecraftClient mc = MinecraftClient.getInstance();
		mc.send(() -> mc.setScreen(new ChatSearchScreen(null, query)));
	}
}
