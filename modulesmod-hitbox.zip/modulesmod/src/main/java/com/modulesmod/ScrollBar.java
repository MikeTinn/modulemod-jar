package com.modulesmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** A scrollbar you can drag with the mouse (and click on the track to jump). */
final class ScrollBar {
	private boolean dragging = false;
	private boolean wasDown = false;
	private int grab = 0;

	private static int thumbHeight(int viewH, int contentH) {
		return Math.max(16, (int) ((long) viewH * viewH / Math.max(1, contentH)));
	}

	/** Call every frame before drawing. Returns the new scroll position. */
	int update(int mouseX, int mouseY, int scroll, int maxScroll, int barX, int top, int bottom, int contentH) {
		boolean down = MinecraftClient.getInstance().mouse.wasLeftButtonClicked();
		int viewH = bottom - top;
		int thumbH = thumbHeight(viewH, contentH);
		int range = Math.max(1, viewH - thumbH);
		int thumbY = top + (int) ((long) range * scroll / Math.max(1, maxScroll));

		boolean pressed = down && !wasDown;
		if (pressed && mouseX >= barX - 3 && mouseX <= barX + 9 && mouseY >= top && mouseY <= bottom) {
			dragging = true;
			grab = (mouseY >= thumbY && mouseY <= thumbY + thumbH) ? mouseY - thumbY : thumbH / 2;
		}
		if (!down) dragging = false;
		wasDown = down;

		if (dragging) {
			int newThumb = Math.max(top, Math.min(top + range, mouseY - grab));
			return (int) Math.round((double) (newThumb - top) * maxScroll / range);
		}
		return scroll;
	}

	void draw(DrawContext ctx, int barX, int top, int bottom, int contentH, int scroll, int maxScroll) {
		int viewH = bottom - top;
		int thumbH = thumbHeight(viewH, contentH);
		int range = Math.max(1, viewH - thumbH);
		int thumbY = top + (int) ((long) range * scroll / Math.max(1, maxScroll));
		ctx.fill(barX, top, barX + 5, bottom, 0x40FFFFFF);
		ctx.fill(barX, thumbY, barX + 5, thumbY + thumbH, dragging ? 0xFFFFFFFF : 0xFFAAAAAA);
	}
}
