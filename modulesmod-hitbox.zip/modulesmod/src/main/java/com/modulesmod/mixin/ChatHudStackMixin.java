package com.modulesmod.mixin;

import com.modulesmod.ChatState;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Chat stacking. When a message repeats, the new copy (with its "(x2)") is added as normal and
 * then the old copy's lines are removed. Both lists are newest-first.
 * This class is in the optional mixin config: if Minecraft renames those lists, only stacking stops working.
 */
@Mixin(ChatHud.class)
public class ChatHudStackMixin {
	private static final String ADD =
			"addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V";

	@Shadow @Final private List<ChatHudLine> messages;
	@Shadow @Final private List<ChatHudLine.Visible> visibleMessages;

	@Unique private int modulesmod$linesBefore = 0;

	@Inject(method = ADD, at = @At("HEAD"), require = 0)
	private void modulesmod$stackHead(Text message, MessageSignatureData signature, MessageIndicator indicator, CallbackInfo ci) {
		modulesmod$linesBefore = visibleMessages.size();
	}

	@Inject(method = ADD, at = @At("RETURN"), require = 0)
	private void modulesmod$stackReturn(Text message, MessageSignatureData signature, MessageIndicator indicator, CallbackInfo ci) {
		int after = visibleMessages.size();
		int added = Math.max(1, after - modulesmod$linesBefore);
		int remove = ChatState.stackRemove;
		ChatState.stackRemove = 0;

		if (remove > 0 && after >= added + remove) {
			visibleMessages.subList(added, added + remove).clear();
			if (messages.size() > 1) messages.remove(1);
		}
		ChatState.lastVisibleLines = added;
	}
}
