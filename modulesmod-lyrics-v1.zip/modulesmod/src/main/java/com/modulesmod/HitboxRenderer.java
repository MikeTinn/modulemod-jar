package com.modulesmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DrawStyle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.debug.gizmo.GizmoDrawing;

/**
 * Draws entity hitboxes through vanilla's own gizmo renderer (the same one F3+B uses), so they are
 * depth tested like vanilla: nothing shows through walls, and invisible entities stay hidden.
 * Called every frame from DebugRendererMixin.
 */
public final class HitboxRenderer {
	private HitboxRenderer() {}

	public static void emit(float tickProgress) {
		if (!Modules.HITBOX.isEnabled()) return;
		Diagnostics.hitboxEmit++;
		try {
			draw(tickProgress);
		} catch (Exception e) {
			Diagnostics.error("hitbox", e);
		}
	}

	private static void draw(float tickProgress) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null || mc.player == null) return;
		// same rule as vanilla F3+B: servers can turn debug info off, and then no hitboxes
		if (mc.player.hasReducedDebugInfo()) return;

		int base = HudUtil.rgb(Modules.HB_COLOR.str, 0xFFFFFF);
		int aim = HudUtil.rgb(Modules.HB_AIM_COLOR.str, 0xFF5555);
		float width = (float) Modules.HB_WIDTH.num;
		boolean fill = Modules.HB_FILL.bool;
		int fillAlpha = HudUtil.alpha(Modules.HB_FILL_OPACITY.num);
		boolean hideEye = Modules.HB_HIDE_EYE.bool;
		boolean hideLook = Modules.HB_HIDE_LOOK.bool;
		int target = Modules.HB_TARGET.index(); // 0 everything, 1 players, 2 everything but players

		Entity camera = mc.getCameraEntity();
		boolean firstPerson = mc.options.getPerspective().isFirstPerson();

		for (Entity e : mc.world.getEntities()) {
			if (e.isInvisible()) continue;
			if (e == camera && firstPerson) continue;
			if (mc.player.squaredDistanceTo(e) > 96.0 * 96.0) continue;

			boolean isPlayer = e instanceof PlayerEntity;
			if (target == 1 && !isPlayer) continue;
			if (target == 2 && isPlayer) continue;

			Vec3d lerped = e.getLerpedPos(tickProgress);
			Vec3d off = new Vec3d(lerped.x - e.getX(), lerped.y - e.getY(), lerped.z - e.getZ());
			Box box = e.getBoundingBox().offset(off);

			int rgb = (mc.targetedEntity == e) ? aim : base;
			int stroke = 0xFF000000 | rgb;
			DrawStyle style = fill
					? DrawStyle.filledAndStroked(stroke, width, (fillAlpha << 24) | rgb)
					: DrawStyle.stroked(stroke, width);
			GizmoDrawing.box(box, style);

			if (e instanceof LivingEntity) {
				double eyeY = e.getEyeY() + off.y;
				if (!hideEye) {
					Box eyeBox = new Box(box.minX, eyeY - 0.01, box.minZ, box.maxX, eyeY + 0.01, box.maxZ);
					GizmoDrawing.box(eyeBox, DrawStyle.stroked(stroke, width));
				}
				if (!hideLook) {
					Vec3d eye = new Vec3d(lerped.x, eyeY, lerped.z);
					Vec3d dir = e.getRotationVec(tickProgress);
					GizmoDrawing.line(eye, eye.add(dir.multiply(2.0)), stroke, width);
				}
			}
		}
	}
}
