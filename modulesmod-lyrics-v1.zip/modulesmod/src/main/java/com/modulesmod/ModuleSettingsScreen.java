package com.modulesmod;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ModuleSettingsScreen extends Screen {
	private static final int W = 380;
	private static final int ROW_H = 28;
	private static final int TOP = 44;

	private final Screen parent;
	private final Module module;
	private final List<Object> snapshot = new ArrayList<>();
	private final List<Entry> entries = new ArrayList<>();
	private final ScrollBar scrollBar = new ScrollBar();
	private ButtonWidget upButton;
	private ButtonWidget downButton;
	private String query = "";
	private int scroll = 0;
	private int maxScroll = 0;

	private static class Entry {
		final Setting setting;
		final ClickableWidget control;
		final ButtonWidget reset; // null for rows without a Reset button
		int y;

		Entry(Setting setting, ClickableWidget control, ButtonWidget reset) {
			this.setting = setting;
			this.control = control;
			this.reset = reset;
		}
	}

	public ModuleSettingsScreen(Screen parent, Module module) {
		super(Text.literal(module.name));
		this.parent = parent;
		this.module = module;
		for (Setting s : module.settings) snapshot.add(s.snapshot());
	}

	private int bottom() {
		return height - 34;
	}

	private int contentH() {
		return entries.size() * ROW_H;
	}

	private int barX() {
		return (width - W) / 2 + W + 8;
	}

	@Override
	protected void init() {
		entries.clear();
		int left = (width - W) / 2;

		TextFieldWidget search = new TextFieldWidget(textRenderer, left, 16, W, 20, Text.literal("Search"));
		search.setPlaceholder(Text.literal("Search..."));
		search.setText(query);
		search.setChangedListener(s -> {
			query = s;
			clearAndInit();
		});
		addDrawableChild(search);

		int controlX = left + W - 50 - 5 - 145;
		int resetX = left + W - 50;

		for (Setting s : module.settings) {
			if (!query.isEmpty() && !s.label.toLowerCase().contains(query.toLowerCase())) continue;

			ClickableWidget control = createControl(s, controlX);
			addDrawableChild(control);

			ButtonWidget reset = null;
			if (s.type != Setting.Type.PRESET && s.type != Setting.Type.ACTION) {
				reset = ButtonWidget.builder(Text.literal("Reset"), b -> {
					s.reset();
					clearAndInit();
				}).dimensions(resetX, 0, 50, 20).build();
				addDrawableChild(reset);
			}

			entries.add(new Entry(s, control, reset));
		}

		addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close())
				.dimensions(width / 2 - 155, height - 28, 150, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Save & Quit"), b -> {
			Modules.save();
			client.setScreen(parent);
		}).dimensions(width / 2 + 5, height - 28, 150, 20).build());

		// up / down arrows next to the scrollbar (shown only when the list is longer than the screen)
		upButton = ButtonWidget.builder(Text.literal("\u25B2"), b -> scrollBy(-ROW_H * 2))
				.dimensions(barX() - 4, 18, 14, 14).build();
		downButton = ButtonWidget.builder(Text.literal("\u25BC"), b -> scrollBy(ROW_H * 2))
				.dimensions(barX() - 4, bottom() + 4, 14, 14).build();
		addDrawableChild(upButton);
		addDrawableChild(downButton);

		layout();
	}

	private ClickableWidget createControl(Setting s, int x) {
		return switch (s.type) {
			case BOOL -> ButtonWidget.builder(boolText(s), b -> {
				s.bool = !s.bool;
				b.setMessage(boolText(s));
			}).dimensions(x, 0, 145, 20).build();

			case CHOICE -> ButtonWidget.builder(Text.literal(s.choice()), b -> {
				s.num = (s.index() + 1) % s.options.length;
				b.setMessage(Text.literal(s.choice()));
			}).dimensions(x, 0, 145, 20).build();

			case SLIDER -> new SettingSlider(x, 0, 145, 20, s);

			case INT, TEXT -> textField(s, x);

			// colors open a real color picker instead of asking for hex codes
			case HEX -> ButtonWidget.builder(colorText(s), b -> client.setScreen(new ColorPickerScreen(this, s)))
					.dimensions(x, 0, 145, 20).build();

			case PRESET -> ButtonWidget.builder(Text.literal(AspectPresets.label(s.linked.num)), b -> {
				s.linked.num = AspectPresets.next(s.linked.num);
				clearAndInit();
			}).dimensions(x, 0, 145, 20).build();

			case ACTION -> ButtonWidget.builder(Text.literal(s.buttonText), b -> {
				s.action.run();
				clearAndInit();
			}).dimensions(x, 0, 145, 20).build();
		};
	}

	private TextFieldWidget textField(Setting s, int x) {
		TextFieldWidget f = new TextFieldWidget(textRenderer, x, 0, 145, 20, Text.literal(s.label));
		if (s.type == Setting.Type.INT) {
			f.setTextPredicate(t -> t.matches("-?\\d{0,9}"));
		} else {
			f.setMaxLength(60);
		}
		f.setText(s.type == Setting.Type.INT ? String.valueOf((int) s.num) : s.str);
		f.setChangedListener(t -> {
			if (s.type == Setting.Type.INT) {
				try {
					s.num = Integer.parseInt(t);
				} catch (NumberFormatException ignored) {
				}
			} else {
				s.str = t;
			}
		});
		return f;
	}

	private static Text boolText(Setting s) {
		return Text.literal(s.bool ? "Yes" : "No").formatted(s.bool ? Formatting.GREEN : Formatting.RED);
	}

	static Text colorText(Setting s) {
		int rgb = HudUtil.rgb(s.str, 0xFFFFFF);
		return Text.literal("\u2588\u2588\u2588 ").setStyle(Style.EMPTY.withColor(rgb))
				.append(Text.literal("#" + s.str.toUpperCase(Locale.ROOT)).formatted(Formatting.WHITE));
	}

	private void scrollBy(int delta) {
		scroll = Math.max(0, Math.min(maxScroll, scroll + delta));
		layout();
	}

	/** Positions every row for the current scroll and hides rows outside the visible area. */
	private void layout() {
		int bottom = bottom();
		int viewH = bottom - TOP;
		maxScroll = Math.max(0, contentH() - viewH);
		scroll = Math.max(0, Math.min(maxScroll, scroll));

		for (int i = 0; i < entries.size(); i++) {
			Entry e = entries.get(i);
			int y = TOP + 2 + i * ROW_H - scroll;
			boolean vis = y >= TOP && y + 20 <= bottom;
			e.y = y;
			e.control.setY(y);
			e.control.visible = vis;
			e.control.active = vis;
			if (e.reset != null) {
				e.reset.setY(y);
				e.reset.visible = vis;
				e.reset.active = vis;
			}
		}

		boolean arrows = maxScroll > 0;
		if (upButton != null) {
			upButton.visible = arrows;
			upButton.active = arrows;
			downButton.visible = arrows;
			downButton.active = arrows;
		}
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		if (maxScroll > 0) {
			scrollBy(-(int) (verticalAmount * 14));
			return true;
		}
		return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (maxScroll > 0 && click.button() == 0
				&& scrollBar.press(click.x(), click.y(), scroll, maxScroll, barX(), TOP, bottom(), contentH())) {
			scroll = scrollBar.drag(click.y(), maxScroll, TOP, bottom(), contentH());
			layout();
			return true;
		}
		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(Click click, double offsetX, double offsetY) {
		if (scrollBar.isDragging()) {
			scroll = scrollBar.drag(click.y(), maxScroll, TOP, bottom(), contentH());
			layout();
			return true;
		}
		return super.mouseDragged(click, offsetX, offsetY);
	}

	@Override
	public boolean mouseReleased(Click click) {
		scrollBar.release();
		return super.mouseReleased(click);
	}

	/** Close = Cancel: throw away unsaved changes. */
	@Override
	public void close() {
		for (int i = 0; i < module.settings.size(); i++) {
			module.settings.get(i).restore(snapshot.get(i));
		}
		client.setScreen(parent);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		ctx.drawTextWithShadow(textRenderer, module.name, (width - textRenderer.getWidth(module.name)) / 2, 4, 0xFFFFFFFF);

		int left = (width - W) / 2;
		int bottom = bottom();
		for (Entry e : entries) {
			if (e.y >= TOP && e.y + 20 <= bottom) {
				ctx.drawTextWithShadow(textRenderer, e.setting.label, left, e.y + 6, 0xFFFFFFFF);
			}
		}

		if (maxScroll > 0) {
			scrollBar.draw(ctx, barX(), TOP, bottom, contentH(), scroll, maxScroll);
		}
	}

	private static class SettingSlider extends SliderWidget {
		private final Setting s;

		SettingSlider(int x, int y, int w, int h, Setting s) {
			super(x, y, w, h, Text.empty(), (s.num - s.min) / (s.max - s.min));
			this.s = s;
			updateMessage();
		}

		@Override
		protected void updateMessage() {
			if (s == null) return;
			setMessage(Text.literal("Value: " + String.format(Locale.ROOT, "%." + s.decimals + "f", s.num)));
		}

		@Override
		protected void applyValue() {
			double p = Math.pow(10, s.decimals);
			s.num = Math.round((s.min + value * (s.max - s.min)) * p) / p;
		}
	}
}
