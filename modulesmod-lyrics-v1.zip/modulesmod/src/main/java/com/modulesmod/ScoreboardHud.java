package com.modulesmod;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.number.NumberFormat;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Replaces the vanilla sidebar scoreboard with our own drawing code so every
 * Scoreboard setting can be applied. When the module is off, vanilla draws as usual.
 */
public final class ScoreboardHud {
	// index matches Modules.SB_FONT options; null = vanilla default font
	private static final Identifier[] FONTS = {
			null,
			Identifier.of("minecraft", "uniform"),
			Identifier.of("minecraft", "alt"),
			Identifier.of("minecraft", "illageralt")
	};

	private record Line(Text name, Text score) {}

	private ScoreboardHud() {}

	public static void register() {
		HudElementRegistry.replaceElement(VanillaHudElements.SCOREBOARD, vanilla -> (ctx, tickCounter) -> {
			if (!Modules.SCOREBOARD.isEnabled()) {
				vanilla.render(ctx, tickCounter);
				return;
			}
			render(ctx);
		});
	}

	private static void render(DrawContext ctx) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null || mc.player == null) return;

		Scoreboard sb = mc.world.getScoreboard();

		// same objective choice as vanilla: team colour slot first, then the sidebar
		ScoreboardObjective obj = null;
		Team playerTeam = sb.getScoreHolderTeam(mc.player.getNameForScoreboard());
		if (playerTeam != null) {
			try {
				ScoreboardDisplaySlot slot = ScoreboardDisplaySlot.valueOf(
						"TEAM_" + playerTeam.getColor().getName().toUpperCase(Locale.ROOT));
				obj = sb.getObjectiveForSlot(slot);
			} catch (IllegalArgumentException ignored) {
				// team has no colour slot (e.g. RESET) -> fall back to the sidebar
			}
		}
		if (obj == null) obj = sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
		if (obj == null) return;

		// ---- settings ----
		int fontIdx = Modules.SB_FONT.index();
		boolean bold = Modules.SB_BOLD.bool;
		boolean italic = Modules.SB_ITALIC.bool;
		boolean shadow = Modules.SB_SHADOW.bool;
		boolean hideTitle = Modules.SB_HIDE_TITLE.bool;
		boolean hideNumbers = Modules.SB_HIDE_NUMBERS.bool;
		float scale = (float) Modules.SB_SCALE.num;
		int textColor = parseColor(Modules.SB_COLOR.str);
		Set<Integer> hiddenRows = parseRows(Modules.SB_HIDDEN_ROWS.str);
		List<String> hiddenWords = parseWords(Modules.SB_HIDDEN_TEXT.str);

		int alpha = (int) Math.round(Math.max(0, Math.min(100, Modules.SB_OPACITY.num)) / 100.0 * 255.0);
		int titleAlpha = Math.min(255, (int) Math.round(alpha * 1.34));
		int rowBg = alpha << 24;
		int titleBg = titleAlpha << 24;

		// ---- collect rows (vanilla order, max 15) ----
		List<ScoreboardEntry> all = new ArrayList<>();
		for (ScoreboardEntry e : sb.getScoreboardEntries(obj)) {
			if (!e.hidden()) all.add(e);
		}
		all.sort((a, b) -> {
			int c = Integer.compare(b.value(), a.value());
			return c != 0 ? c : String.CASE_INSENSITIVE_ORDER.compare(a.owner(), b.owner());
		});
		if (all.size() > 15) all = new ArrayList<>(all.subList(0, 15));

		NumberFormat numberFormat = obj.getNumberFormatOr(StyledNumberFormat.RED);

		List<Line> lines = new ArrayList<>();
		for (int i = 0; i < all.size(); i++) {
			if (hiddenRows.contains(i + 1)) continue;
			ScoreboardEntry e = all.get(i);
			Text name = Team.decorateName(sb.getScoreHolderTeam(e.owner()), e.name());
			String plain = name.getString().toLowerCase(Locale.ROOT);
			boolean skip = false;
			for (String w : hiddenWords) {
				if (plain.contains(w)) {
					skip = true;
					break;
				}
			}
			if (skip) continue;
			Text score = hideNumbers ? Text.empty() : e.formatted(numberFormat);
			lines.add(new Line(style(name, fontIdx, bold, italic), style(score, fontIdx, bold, italic)));
		}

		if (lines.isEmpty() && hideTitle) return;

		TextRenderer tr = mc.textRenderer;
		Text title = style(obj.getDisplayName(), fontIdx, bold, italic);
		int spaceW = tr.getWidth(style(Text.literal(": "), fontIdx, bold, italic));

		int maxW = hideTitle ? 0 : tr.getWidth(title);
		for (Line l : lines) {
			int w = tr.getWidth(l.name());
			int sw = tr.getWidth(l.score());
			if (sw > 0) w += spaceW + sw;
			maxW = Math.max(maxW, w);
		}

		// ---- layout (vanilla placement: right edge, vertically centered) ----
		final int lineH = 9;
		int rowsH = lines.size() * lineH;
		int screenW = ctx.getScaledWindowWidth();
		int screenH = ctx.getScaledWindowHeight();
		int bottom = screenH / 2 + rowsH / 3;
		int rowsTop = bottom - rowsH;
		int right = screenW - 1;
		int left = right - maxW - 4;
		int boardTop = hideTitle ? rowsTop - 1 : rowsTop - 10;
		int centerY = (boardTop + bottom) / 2;

		ctx.getMatrices().pushMatrix();
		ctx.getMatrices().translate((float) right, (float) centerY);
		ctx.getMatrices().scale(scale, scale);
		ctx.getMatrices().translate((float) -right, (float) -centerY);

		if (!hideTitle) {
			ctx.fill(left, rowsTop - 10, right, rowsTop - 1, titleBg);
		}
		ctx.fill(left, rowsTop - 1, right, bottom, rowBg);

		if (!hideTitle) {
			int tx = left + 2 + (maxW - tr.getWidth(title)) / 2;
			ctx.drawText(tr, title, tx, rowsTop - 9, textColor, shadow);
		}

		for (int i = 0; i < lines.size(); i++) {
			Line l = lines.get(i);
			int y = rowsTop + i * lineH;
			ctx.drawText(tr, l.name(), left + 2, y, textColor, shadow);
			int sw = tr.getWidth(l.score());
			if (sw > 0) {
				ctx.drawText(tr, l.score(), right - 2 - sw, y, textColor, shadow);
			}
		}

		ctx.getMatrices().popMatrix();
	}

	/** Applies font / bold / italic on top of whatever styling the server already set. */
	private static Text style(Text t, int fontIdx, boolean bold, boolean italic) {
		if (fontIdx <= 0 && !bold && !italic) return t;
		return t.copy().styled(s -> {
			if (fontIdx > 0 && fontIdx < FONTS.length) s = s.withFont(new StyleSpriteSource.Font(FONTS[fontIdx]));
			if (bold) s = s.withBold(true);
			if (italic) s = s.withItalic(true);
			return s;
		});
	}

	private static int parseColor(String hex) {
		try {
			if (hex != null && hex.length() == 6) return 0xFF000000 | Integer.parseInt(hex, 16);
		} catch (NumberFormatException ignored) {
		}
		return 0xFFFFFFFF;
	}

	/** "1,3,5-7" -> {1,3,5,6,7} */
	private static Set<Integer> parseRows(String csv) {
		Set<Integer> out = new HashSet<>();
		if (csv == null) return out;
		for (String part : csv.split("[,\\s]+")) {
			if (part.isEmpty()) continue;
			try {
				int dash = part.indexOf('-', 1);
				if (dash > 0) {
					int a = Integer.parseInt(part.substring(0, dash));
					int b = Integer.parseInt(part.substring(dash + 1));
					for (int i = a; i <= b && i - a < 50; i++) out.add(i);
				} else {
					out.add(Integer.parseInt(part));
				}
			} catch (NumberFormatException ignored) {
			}
		}
		return out;
	}

	private static List<String> parseWords(String csv) {
		List<String> out = new ArrayList<>();
		if (csv == null) return out;
		for (String part : csv.split(",")) {
			String w = part.trim().toLowerCase(Locale.ROOT);
			if (!w.isEmpty()) out.add(w);
		}
		return out;
	}
}
