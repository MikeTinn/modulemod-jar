package com.modulesmod;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.world.GameMode;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

/**
 * Replaces the vanilla player list (Tab) with our own drawing code so every Tab
 * setting can be applied. When the module is off, vanilla draws as usual.
 */
public final class TabHud {
	/** Filled by PlayerListHudMixin when the server sends a header / footer. */
	public static volatile Text header;
	public static volatile Text footer;

	private record Cell(PlayerListEntry entry, Text name, boolean own) {}

	private TabHud() {}

	public static void register() {
		HudElementRegistry.replaceElement(VanillaHudElements.PLAYER_LIST, vanilla -> (ctx, tickCounter) -> {
			if (!Modules.TAB.isEnabled()) {
				vanilla.render(ctx, tickCounter);
				return;
			}
			render(ctx);
		});
	}

	private static void render(DrawContext ctx) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null || mc.player == null) return;
		ClientPlayNetworkHandler nh = mc.getNetworkHandler();
		if (nh == null) return;
		if (!mc.options.playerListKey.isPressed()) return;

		// same "when to show" rule as vanilla
		Collection<PlayerListEntry> listed = nh.getListedPlayerListEntries();
		ScoreboardObjective listObjective = mc.world.getScoreboard().getObjectiveForSlot(ScoreboardDisplaySlot.LIST);
		if (mc.isInSingleplayer() && listed.size() <= 1 && listObjective == null) return;

		TextRenderer tr = mc.textRenderer;
		PlayerListHud vanillaHud = mc.inGameHud.getPlayerListHud();

		// ---- settings ----
		int textColor = 0xFF000000 | HudUtil.rgb(Modules.T_TEXT_COLOR.str, 0xFFFFFF);
		int bgRgb = HudUtil.rgb(Modules.T_BG_COLOR.str, 0x000000);
		int bg = (HudUtil.alpha(Modules.T_OPACITY.num) << 24) | bgRgb;
		boolean rowBg = Modules.T_ROW_BG.bool;
		boolean shadow = Modules.T_SHADOW.bool;
		boolean heads = Modules.T_HEADS.bool;
		int pingStyle = Modules.T_PING.index(); // 0 off, 1 number, 2 bars
		int maxPlayers = Math.max(1, (int) Modules.T_MAX.num);
		float userScale = (float) Modules.T_SCALE.num;

		boolean ownOn = Modules.T_OWN.bool;
		int ownRgb = HudUtil.rgb(Modules.T_OWN_COLOR.str, 0xFFFF55);
		boolean ownBold = Modules.T_OWN_BOLD.bool;
		boolean ownUnderline = Modules.T_OWN_UL.bool;
		boolean ownRowBg = Modules.T_OWN_BG.bool;

		int[] pingColors = {
				0xFF000000 | HudUtil.rgb(Modules.T_PING_1.str, 0x55FF55),
				0xFF000000 | HudUtil.rgb(Modules.T_PING_2.str, 0xAAFF55),
				0xFF000000 | HudUtil.rgb(Modules.T_PING_3.str, 0xFFFF55),
				0xFF000000 | HudUtil.rgb(Modules.T_PING_4.str, 0xFFAA00),
				0xFF000000 | HudUtil.rgb(Modules.T_PING_5.str, 0xFF5555)
		};

		// ---- players: spectators last, then team, then name (like vanilla) ----
		List<PlayerListEntry> entries = new ArrayList<>(listed);
		entries.sort((a, b) -> {
			int c = Integer.compare(a.getGameMode() == GameMode.SPECTATOR ? 1 : 0,
					b.getGameMode() == GameMode.SPECTATOR ? 1 : 0);
			if (c != 0) return c;
			Team ta = a.getScoreboardTeam();
			Team tb = b.getScoreboardTeam();
			c = (ta == null ? "" : ta.getName()).compareTo(tb == null ? "" : tb.getName());
			if (c != 0) return c;
			return String.CASE_INSENSITIVE_ORDER.compare(
					vanillaHud.getPlayerName(a).getString(), vanillaHud.getPlayerName(b).getString());
		});
		if (entries.size() > maxPlayers) entries = new ArrayList<>(entries.subList(0, maxPlayers));

		PlayerListEntry ownEntry = nh.getPlayerListEntry(mc.player.getUuid());

		List<Cell> cells = new ArrayList<>();
		int maxNameW = 0;
		int pingW = pingStyle == 2 ? 14 : 0;
		for (PlayerListEntry e : entries) {
			boolean own = ownOn && e == ownEntry;
			Text name = vanillaHud.getPlayerName(e);
			if (own) {
				Style st = Style.EMPTY.withColor(ownRgb);
				if (ownBold) st = st.withBold(true);
				if (ownUnderline) st = st.withUnderline(true);
				name = Text.literal(name.getString()).setStyle(st);
			}
			cells.add(new Cell(e, name, own));
			maxNameW = Math.max(maxNameW, tr.getWidth(name));
			if (pingStyle == 1) pingW = Math.max(pingW, tr.getWidth(pingText(e.getLatency())));
		}

		// ---- header / footer ----
		int screenW = ctx.getScaledWindowWidth();
		Text h = header;
		Text f = footer;
		List<OrderedText> headerLines = (Modules.T_HIDE_HEADER.bool || h == null)
				? List.of() : tr.wrapLines(h, screenW - 50);
		List<OrderedText> footerLines = (Modules.T_HIDE_FOOTER.bool || f == null)
				? List.of() : tr.wrapLines(f, screenW - 50);
		int headerW = 0;
		for (OrderedText l : headerLines) headerW = Math.max(headerW, tr.getWidth(l));
		int footerW = 0;
		for (OrderedText l : footerLines) footerW = Math.max(footerW, tr.getWidth(l));

		if (cells.isEmpty() && headerLines.isEmpty() && footerLines.isEmpty()) return;

		// ---- grid: up to 20 rows per column, like vanilla ----
		int n = cells.size();
		int rows = Math.max(n, 1);
		int cols = 1;
		while (rows > 20) {
			cols++;
			rows = (n + cols - 1) / cols;
		}
		int headW = heads ? 9 : 0;
		int cellW = headW + maxNameW + (pingStyle == 0 ? 1 : 4 + pingW) + 1;
		int listW = n == 0 ? 0 : cols * cellW + (cols - 1) * 5;

		int blockW = Math.max(listW, Math.max(headerW, footerW)) + 2;
		float scale = Math.min(userScale, (screenW - 10) / (float) blockW); // never wider than the screen
		int cx = screenW / 2;
		int top = 10;

		ctx.getMatrices().pushMatrix();
		ctx.getMatrices().translate((float) cx, (float) top);
		ctx.getMatrices().scale(scale, scale);
		ctx.getMatrices().translate((float) -cx, (float) -top);

		int y = top;

		// header
		if (!headerLines.isEmpty()) {
			int hh = headerLines.size() * 9;
			ctx.fill(cx - headerW / 2 - 1, y - 1, cx + headerW / 2 + 1, y + hh, bg);
			for (int i = 0; i < headerLines.size(); i++) {
				OrderedText l = headerLines.get(i);
				ctx.drawText(tr, l, cx - tr.getWidth(l) / 2, y + i * 9, textColor, shadow);
			}
			y += hh + 2;
		}

		// player grid
		if (n > 0) {
			int x0 = cx - listW / 2;
			ctx.fill(x0 - 1, y - 1, x0 + listW + 1, y + rows * 9, bg);

			for (int i = 0; i < n; i++) {
				Cell cell = cells.get(i);
				int col = i / rows;
				int row = i % rows;
				int cellX = x0 + col * (cellW + 5);
				int cellY = y + row * 9;

				if (cell.own() && ownRowBg) {
					ctx.fill(cellX, cellY, cellX + cellW, cellY + 8, 0x50000000 | ownRgb);
				} else if (rowBg) {
					ctx.fill(cellX, cellY, cellX + cellW, cellY + 8, 0x20FFFFFF);
				}

				int nameX = cellX;
				if (heads) {
					PlayerSkinDrawer.draw(ctx, cell.entry().getSkinTextures(), cellX, cellY, 8);
					nameX += 9;
				}
				ctx.drawText(tr, cell.name(), nameX, cellY, textColor, shadow);

				if (pingStyle != 0) {
					int ping = cell.entry().getLatency();
					int pingX = cellX + cellW - 1 - pingW;
					if (pingStyle == 2) {
						drawBars(ctx, pingX, cellY, ping, pingColors);
					} else {
						String txt = pingText(ping);
						int color = ping < 0 ? 0xFF808080 : pingColor(ping, pingColors);
						ctx.drawText(tr, txt, pingX + pingW - tr.getWidth(txt), cellY, color, shadow);
					}
				}
			}
			y += rows * 9 + 2;
		}

		// footer
		if (!footerLines.isEmpty()) {
			int fh = footerLines.size() * 9;
			ctx.fill(cx - footerW / 2 - 1, y - 1, cx + footerW / 2 + 1, y + fh, bg);
			for (int i = 0; i < footerLines.size(); i++) {
				OrderedText l = footerLines.get(i);
				ctx.drawText(tr, l, cx - tr.getWidth(l) / 2, y + i * 9, textColor, shadow);
			}
		}

		ctx.getMatrices().popMatrix();
	}

	private static String pingText(int ping) {
		return ping < 0 ? "?" : ping + "ms";
	}

	private static int pingColor(int ping, int[] c) {
		if (ping <= 50) return c[0];
		if (ping <= 100) return c[1];
		if (ping <= 150) return c[2];
		if (ping <= 250) return c[3];
		return c[4];
	}

	private static void drawBars(DrawContext ctx, int x, int y, int ping, int[] colors) {
		int filled = ping < 0 ? 0 : ping < 150 ? 5 : ping < 300 ? 4 : ping < 600 ? 3 : ping < 1000 ? 2 : 1;
		int color = ping < 0 ? 0xFF808080 : pingColor(ping, colors);
		int[] heights = {2, 3, 5, 6, 8};
		for (int i = 0; i < 5; i++) {
			int bx = x + i * 3;
			ctx.fill(bx, y + 8 - heights[i], bx + 2, y + 8, i < filled ? color : 0xFF303030);
		}
	}
}
