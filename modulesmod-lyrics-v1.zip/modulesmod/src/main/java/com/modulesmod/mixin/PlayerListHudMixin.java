package com.modulesmod.mixin;

import com.modulesmod.TabHud;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Vanilla keeps the header/footer private, so we copy them when the server sends them. */
@Mixin(PlayerListHud.class)
public class PlayerListHudMixin {
	@Inject(method = "setHeader", at = @At("HEAD"), require = 0)
	private void modulesmod$header(Text header, CallbackInfo ci) {
		TabHud.header = header;
	}

	@Inject(method = "setFooter", at = @At("HEAD"), require = 0)
	private void modulesmod$footer(Text footer, CallbackInfo ci) {
		TabHud.footer = footer;
	}

	@Inject(method = "clear", at = @At("HEAD"), require = 0)
	private void modulesmod$clear(CallbackInfo ci) {
		TabHud.header = null;
		TabHud.footer = null;
	}
}
