package com.modulesmod.mixin;

import com.modulesmod.BlockOutlineRenderer;
import com.modulesmod.Diagnostics;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.state.WorldRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides the vanilla block outline while the Block Outline module is drawing its own. */
@Mixin(WorldRenderer.class)
public class WorldRendererMixin {
	@Inject(method = "renderTargetBlockOutline(Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/util/math/MatrixStack;ZLnet/minecraft/client/render/state/WorldRenderState;)V",
			at = @At("HEAD"), cancellable = true, require = 0)
	private void modulesmod$replaceVanillaOutline(VertexConsumerProvider.Immediate immediate, MatrixStack matrices,
												  boolean renderBlockOutline, WorldRenderState renderStates, CallbackInfo ci) {
		if (BlockOutlineRenderer.replacesVanilla()) {
			Diagnostics.outlineVanillaCancelled++;
			ci.cancel();
		}
	}
}
