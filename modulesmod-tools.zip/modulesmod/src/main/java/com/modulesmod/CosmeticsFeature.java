package com.modulesmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityPose;

/** Draws the equipped cosmetics on the player layer. Only draws for the local player. */
public final class CosmeticsFeature extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
	public CosmeticsFeature(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
		super(context);
	}

	@Override
	public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
					   PlayerEntityRenderState state, float headYaw, float headPitch) {
		if (!Modules.COSMETICS.isEnabled()) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || state.id != mc.player.getId()) return;

		boolean sneaking = state.isInPose(EntityPose.CROUCHING);
		for (Cosmetics.Def def : Cosmetics.equipped()) {
			try {
				CosmeticModel model = Cosmetics.model(def);
				model.setPose(headYaw, headPitch, sneaking, state.age);
				renderModel(model, def.textureId(), matrices, queue, light, state, -1, 1);
			} catch (Exception e) {
				Diagnostics.error("cosmetic " + def.id(), e);
			}
		}
	}
}
