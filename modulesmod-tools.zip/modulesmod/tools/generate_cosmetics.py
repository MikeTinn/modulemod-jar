#!/usr/bin/env python3
"""
Generates the built-in cosmetics: one shared model file + one texture per cosmetic.
All models and textures are made from scratch here (blocky, vanilla-style) - nothing is copied from anywhere.

Run from the project root:   python3 tools/generate_cosmetics.py
Writes:  src/main/resources/assets/modulesmod/cosmetics/cosmetics.json
         src/main/resources/assets/modulesmod/textures/cosmetics/<id>.png

Model space is the player's: 1 unit = 1/16 block, y points DOWN, the player's front is -z.
  HEAD attach: origin = centre of the head's bottom (head box is x -4..4, y -8..0, z -4..4)
  BODY attach: origin = top centre of the torso (torso box is x -4..4, y 0..12, z -2..2, back is +z)
"""
import json, math, os, random
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "modulesmod")


def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


class Cube:
    def __init__(self, pos, size, color, inflate=0.0, details=None):
        self.pos, self.size, self.color = pos, size, rgb(color)
        self.inflate = inflate
        self.details = details or []   # (face, x, y, w, h, "#color") in face pixels
        self.uv = (0, 0)

    def dims(self):
        w, h, d = (max(1, math.ceil(v)) for v in self.size)
        return w, h, d

    def rect_size(self):
        w, h, d = self.dims()
        return 2 * d + 2 * w, d + h


class Part:
    def __init__(self, name, pivot, rot, cubes):
        self.name, self.pivot, self.rot, self.cubes = name, pivot, rot, cubes


class Cos:
    def __init__(self, id, name, category, attach, anim, accent, parts, amp=1.0):
        self.id, self.name, self.category, self.attach = id, name, category, attach
        self.anim, self.accent, self.parts, self.amp = anim, accent, parts, amp


def face_rects(u, v, w, h, d):
    return {
        "top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h), "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h), "back": (u + 2 * d + w, v + d, w, h),
    }


def pack(cubes):
    """shelf-pack every cube's UV box; returns (texW, texH)."""
    for tw, th in [(64, 64), (128, 64), (128, 128), (256, 128), (256, 256)]:
        x = y = shelf = 0
        ok = True
        for c in sorted(cubes, key=lambda c: -c.rect_size()[1]):
            rw, rh = c.rect_size()
            if x + rw > tw:
                x, y, shelf = 0, y + shelf, 0
            if y + rh > th or rw > tw:
                ok = False
                break
            c.uv = (x, y)
            x += rw
            shelf = max(shelf, rh)
        if ok:
            return tw, th
    raise SystemExit("cosmetic too big for a texture")


def paint(cos, tw, th):
    img = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    px = img.load()
    rnd = random.Random(cos.id)
    tone = {"top": 1.12, "bottom": 0.78, "right": 0.9, "left": 0.9, "front": 1.0, "back": 0.96}
    for part in cos.parts:
        for c in part.cubes:
            w, h, d = c.dims()
            for face, (fx, fy, fw, fh) in face_rects(c.uv[0], c.uv[1], w, h, d).items():
                for yy in range(fh):
                    for xx in range(fw):
                        f = tone[face] * (1 + rnd.uniform(-0.05, 0.05))
                        if fw > 2 and fh > 2 and (xx in (0, fw - 1) or yy in (0, fh - 1)):
                            f *= 0.86
                        px[fx + xx, fy + yy] = shade(c.color, f) + (255,)
            for face, dx, dy, dw, dh, col in c.details:
                fx, fy, fw, fh = face_rects(c.uv[0], c.uv[1], w, h, d)[face]
                for yy in range(dy, min(dy + dh, fh)):
                    for xx in range(dx, min(dx + dw, fw)):
                        px[fx + xx, fy + yy] = rgb(col) + (255,)
    img.save(os.path.join(ROOT, "textures", "cosmetics", cos.id + ".png"))


# ------------------------------------------------------------------ builders

def hat(id, name, accent, cubes):
    return Cos(id, name, "HAT", "HEAD", "none", accent, [Part("hat", (0, 0, 0), (0, 0, 0), cubes)])


def wings(id, name, accent, rows, anim_amp=1.0, bone="#f4f4f4"):
    """rows: (y, height, length, colour). Folded back a little; flap swings them around the vertical axis."""
    right, left = [], []
    for (y, hgt, ln, col) in rows:
        right.append(Cube((-ln, y, 0), (ln, hgt, 1), col))
        left.append(Cube((0, y, 0), (ln, hgt, 1), col))
    return Cos(id, name, "WINGS", "BODY", "flap", accent, [
        Part("right", (-2, 2, 2.5), (0, 0.55, 0), right),
        Part("left", (2, 2, 2.5), (0, -0.55, 0), left),
    ], anim_amp)


def cape(id, name, accent, color, trim, extra=None, collar=None):
    back = [("back", 0, 0, 10, 1, trim), ("back", 0, 15, 10, 1, trim), ("back", 0, 0, 1, 16, trim), ("back", 9, 0, 1, 16, trim)]
    parts = [Part("cape", (0, 0, 2), (0.14, 0, 0), [Cube((-5, 0, 0), (10, 16, 1), color, details=back + (extra or []))])]
    if collar:
        parts.append(Part("collar", (0, 0, 0), (0, 0, 0), [Cube((-6, -1, -3), (12, 2, 6), collar)]))
    return Cos(id, name, "CAPE", "BODY", "sway", accent, parts)


def jacket(id, name, accent, color, trim, hood=None, pocket=None):
    front = [("front", 3, 0, 2, 12, trim)]
    if pocket:
        front.append(("front", 1, 7, 6, 3, pocket))
    parts = [Part("jacket", (0, 0, 0), (0, 0, 0), [
        Cube((-4, 0, -2), (8, 12, 4), color, inflate=0.6, details=front + [("front", 0, 11, 8, 1, trim), ("back", 0, 11, 8, 1, trim)]),
        Cube((-4, -1, -2), (8, 1, 4), trim, inflate=0.7),
    ])]
    if hood:
        parts.append(Part("hood", (0, 0, 0), (0, 0, 0), [Cube((-4, -2, 1.5), (8, 6, 3), hood, inflate=0.2)]))
    return Cos(id, name, "JACKET", "BODY", "none", accent, parts)


def pet(id, name, accent, cubes, pivot=(-6.5, 0, 0), amp=1.0):
    return Cos(id, name, "PET", "BODY", "bob", accent, [Part("pet", pivot, (0, 0, 0), cubes)], amp)


# ------------------------------------------------------------------ the catalogue

def rainbow_rows():
    cols = ["#ff4d4d", "#ff9e3d", "#ffe94d", "#5fe06a", "#4dc3ff", "#a066ff"]
    lens = [6, 9, 10, 9, 7, 5]
    return [(-3 + i * 2, 2, lens[i], cols[i]) for i in range(6)]


COSMETICS = [
    # ---- hats
    hat("top_hat", "Top Hat", "#2b2b33", [
        Cube((-6, -9, -6), (12, 1, 12), "#1c1c22"),
        Cube((-4, -16, -4), (8, 7, 8), "#25252d", details=[("front", 0, 5, 8, 2, "#b3202a"), ("back", 0, 5, 8, 2, "#b3202a"), ("left", 0, 5, 8, 2, "#b3202a"), ("right", 0, 5, 8, 2, "#b3202a")]),
    ]),
    hat("crown", "Gold Crown", "#ffd24a", [
        Cube((-4.5, -11, -4.5), (9, 3, 9), "#ffcc33", details=[("front", 3, 0, 3, 2, "#e03a3a"), ("front", 0, 2, 9, 1, "#d99a14")]),
        Cube((-4.5, -14, -4.5), (2, 3, 2), "#ffd84d"), Cube((2.5, -14, -4.5), (2, 3, 2), "#ffd84d"),
        Cube((-4.5, -14, 2.5), (2, 3, 2), "#ffd84d"), Cube((2.5, -14, 2.5), (2, 3, 2), "#ffd84d"),
        Cube((-1, -14, -4.5), (2, 3, 2), "#ffd84d"), Cube((-1, -14, 2.5), (2, 3, 2), "#ffd84d"),
    ]),
    hat("cat_ears", "Cat Ears", "#ff8fc7", [
        Cube((-4.4, -8.8, -4.4), (9, 1, 9), "#2f2f38"),
        Cube((-4, -11.5, -3), (3, 3, 2), "#3a3a46", details=[("front", 1, 1, 1, 2, "#ff8fc7")]),
        Cube((1, -11.5, -3), (3, 3, 2), "#3a3a46", details=[("front", 1, 1, 1, 2, "#ff8fc7")]),
    ]),
    Cos("halo", "Halo", "HAT", "HEAD", "bob", "#fff4a0", [Part("halo", (0, 0, 0), (0, 0, 0), [
        Cube((-4, -14, -4), (8, 1, 1), "#fff0a0"), Cube((-4, -14, 3), (8, 1, 1), "#fff0a0"),
        Cube((-4, -14, -3), (1, 1, 6), "#ffe566"), Cube((3, -14, -3), (1, 1, 6), "#ffe566"),
    ])], amp=0.6),
    hat("wizard_hat", "Wizard Hat", "#8a5cff", [
        Cube((-6, -9, -6), (12, 1, 12), "#3d2a7a"),
        Cube((-4.5, -12, -4.5), (9, 3, 9), "#4b33a0", details=[("front", 0, 0, 9, 1, "#ffd24a"), ("left", 0, 0, 9, 1, "#ffd24a"), ("right", 0, 0, 9, 1, "#ffd24a"), ("back", 0, 0, 9, 1, "#ffd24a")]),
        Cube((-3.5, -15, -3.5), (7, 3, 7), "#5a3fbd", details=[("front", 2, 1, 1, 1, "#ffe566")]),
        Cube((-2.5, -18, -2.5), (5, 3, 5), "#6a4de0"), Cube((-1.5, -20, -1.5), (3, 2, 3), "#7b5cf5"),
    ]),
    # ---- wings
    wings("angel_wings", "Angel Wings", "#eaf4ff", [
        (-3, 2, 5, "#ffffff"), (-1, 2, 10, "#f2f7ff"), (1, 2, 9, "#e6efff"), (3, 2, 7, "#dce8ff"), (5, 2, 5, "#d0e0ff")]),
    wings("demon_wings", "Demon Wings", "#c0243a", [
        (-5, 2, 5, "#3a0f1a"), (-3, 2, 11, "#5a1224"), (-1, 2, 14, "#7a1630"), (1, 2, 12, "#9a1b3a"), (3, 2, 9, "#b8233f"), (5, 2, 6, "#d12b48")], 1.2),
    wings("rainbow_wings", "Rainbow Wings", "#ffb347", rainbow_rows()),
    # ---- capes
    cape("red_cape", "Red Cape", "#d6303b", "#c42631", "#ffd24a"),
    cape("royal_cape", "Royal Cape", "#7a3fd1", "#5b2aa8", "#ffd24a", collar="#f4f1ea"),
    cape("midnight_cape", "Midnight Cape", "#2f4cc9", "#141a3d", "#4a5fd1",
         extra=[("back", 2, 3, 1, 1, "#ffffff"), ("back", 7, 6, 1, 1, "#ffffff"), ("back", 4, 9, 1, 1, "#cfe0ff"), ("back", 6, 12, 1, 1, "#ffffff"), ("back", 2, 13, 1, 1, "#cfe0ff")]),
    # ---- jackets
    jacket("denim_jacket", "Denim Jacket", "#3c6fb5", "#3b6aa8", "#cdd6e0", pocket="#315a90"),
    jacket("leather_jacket", "Leather Jacket", "#7a4a2b", "#5a3520", "#2a1a10", pocket="#4a2b18"),
    jacket("red_hoodie", "Red Hoodie", "#e0484f", "#c9343c", "#f0f0f0", hood="#b92d35", pocket="#a8262e"),
    # ---- pets (ride on the right shoulder and bob)
    pet("cube_cat", "Cube Cat", "#ffa447", [
        Cube((-2, -3, -2), (4, 3, 4), "#f2933c", details=[("top", 1, 0, 2, 4, "#c9731f")]),
        Cube((-1.75, -6.5, -2.4), (3.5, 3.5, 3.5), "#f6a04d", details=[("front", 0, 1, 1, 1, "#1a1a1a"), ("front", 2, 1, 1, 1, "#1a1a1a"), ("front", 1, 2, 1, 1, "#ff8fa8")]),
        Cube((-1.75, -8, -1.9), (1, 1.5, 1), "#e48a33"), Cube((0.75, -8, -1.9), (1, 1.5, 1), "#e48a33"),
        Cube((-0.5, -2.5, 2), (1, 1, 3), "#e48a33"),
    ]),
    pet("slime_buddy", "Slime Buddy", "#7be06a", [
        Cube((-2.5, -5, -2.5), (5, 5, 5), "#6fd45e", details=[("front", 1, 2, 1, 1, "#1d3a1a"), ("front", 3, 2, 1, 1, "#1d3a1a"), ("front", 2, 3, 1, 1, "#2f6b27")]),
        Cube((-1.5, -4, -1.5), (3, 3, 3), "#4fb040"),
    ], amp=1.4),
    pet("bumble_bee", "Bumble Bee", "#ffd93d", [
        Cube((-2, -4, -2.5), (4, 3, 5), "#ffd93d", details=[("top", 0, 1, 4, 1, "#2a2a2a"), ("top", 0, 3, 4, 1, "#2a2a2a"), ("front", 0, 1, 1, 1, "#1a1a1a"), ("front", 3, 1, 1, 1, "#1a1a1a")]),
        Cube((-2.5, -5.5, -0.5), (2, 1, 3), "#e8f6ff"), Cube((0.5, -5.5, -0.5), (2, 1, 3), "#e8f6ff"),
        Cube((-0.5, -3, 2.5), (1, 1, 1.5), "#2a2a2a"),
    ], pivot=(-7, -3, 0), amp=2.0),
]

EYE = "#15151a"


def eyes(y, a=0, b=3, color=EYE):
    return [("front", a, y, 1, 1, color), ("front", b, y, 1, 1, color)]


MORE_PETS = [
    pet("wolf_pup", "Wolf Pup", "#a9acb3", [
        Cube((-2, -3, -2), (4, 3, 4), "#8c8f96"),
        Cube((-1.75, -6.5, -3.6), (3.5, 3.5, 3.5), "#a9acb3", details=eyes(1)),
        Cube((-0.75, -4.8, -5.2), (1.5, 1.5, 1.6), "#d6d8dc", details=[("front", 0, 0, 2, 1, "#222222")]),
        Cube((-1.75, -8, -2.6), (1, 1.6, 1), "#6d7076"), Cube((0.75, -8, -2.6), (1, 1.6, 1), "#6d7076"),
        Cube((-0.5, -3, 2), (1, 1, 3), "#8c8f96"),
    ]),
    pet("fox_kit", "Fox Kit", "#f08a35", [
        Cube((-2, -3, -2), (4, 3, 4), "#e8782a"),
        Cube((-1.75, -6.5, -3.6), (3.5, 3.5, 3.5), "#f08a35", details=eyes(1) + [("front", 1, 2, 2, 2, "#ffffff")]),
        Cube((-1.75, -8, -2.6), (1, 1.6, 1), "#e8782a", details=[("top", 0, 0, 1, 1, "#222222")]),
        Cube((0.75, -8, -2.6), (1, 1.6, 1), "#e8782a", details=[("top", 0, 0, 1, 1, "#222222")]),
        Cube((-0.75, -3.5, 2), (1.5, 1.5, 3), "#e8782a", details=[("back", 0, 0, 2, 2, "#ffffff")]),
    ]),
    pet("panda_cub", "Panda Cub", "#f4f4f4", [
        Cube((-2, -3, -2), (4, 3, 4), "#f4f4f4", details=[("left", 0, 0, 4, 3, "#2a2a2a"), ("right", 0, 0, 4, 3, "#2a2a2a")]),
        Cube((-1.75, -6.5, -2.6), (3.5, 3.5, 3.5), "#f8f8f8", details=eyes(1, 0, 3, "#2a2a2a") + [("front", 1, 2, 2, 1, "#2a2a2a")]),
        Cube((-1.9, -7.8, -1.6), (1.2, 1.2, 1.2), "#2a2a2a"), Cube((0.7, -7.8, -1.6), (1.2, 1.2, 1.2), "#2a2a2a"),
    ]),
    pet("piglet", "Piglet", "#f4a4b4", [
        Cube((-2, -3, -2.5), (4, 3, 5), "#f4a4b4"),
        Cube((-1.75, -6.5, -3.8), (3.5, 3.5, 3.5), "#f6b0be", details=eyes(1)),
        Cube((-1, -5, -4.8), (2, 1.5, 1), "#e58a9c", details=[("front", 0, 0, 1, 1, "#a0505f"), ("front", 1, 0, 1, 1, "#a0505f")]),
        Cube((-1.75, -7.4, -3), (1, 1, 0.8), "#e58a9c"), Cube((0.75, -7.4, -3), (1, 1, 0.8), "#e58a9c"),
        Cube((-0.4, -2.6, 2.5), (0.8, 0.8, 1), "#e58a9c"),
    ]),
    pet("bunny", "Bunny", "#ffffff", [
        Cube((-2, -3, -2), (4, 3, 4), "#f1f1f1"),
        Cube((-1.75, -6.5, -3), (3.5, 3.5, 3.5), "#f6f6f6", details=eyes(1, 0, 3) + [("front", 1, 2, 2, 1, "#ffb6c8")]),
        Cube((-1.5, -10.5, -1.6), (1, 3.5, 1), "#f6f6f6", details=[("front", 0, 0, 1, 3, "#ffb6c8")]),
        Cube((0.5, -10.5, -1.6), (1, 3.5, 1), "#f6f6f6", details=[("front", 0, 0, 1, 3, "#ffb6c8")]),
        Cube((-0.75, -2.5, 2), (1.5, 1.5, 1.5), "#ffffff"),
    ]),
    pet("baby_dragon", "Baby Dragon", "#4fa845", [
        Cube((-2, -3, -2.5), (4, 3, 5), "#4fa845"),
        Cube((-1.75, -6.5, -4.2), (3.5, 3.5, 3.5), "#5cb852", details=eyes(1, 0, 3, "#ffd84d")),
        Cube((-1.5, -8, -2.8), (0.7, 1.5, 0.7), "#e8e0c8"), Cube((0.8, -8, -2.8), (0.7, 1.5, 0.7), "#e8e0c8"),
        Cube((-0.5, -2.5, 2.5), (1, 1, 3.5), "#3e8a38"),
        Cube((-0.5, -3.8, -1), (1, 0.8, 0.8), "#2f7a2a"), Cube((-0.5, -3.8, 0.6), (1, 0.8, 0.8), "#2f7a2a"),
        Cube((-4, -4, 0), (2, 0.8, 3), "#3e8a38"), Cube((2, -4, 0), (2, 0.8, 3), "#3e8a38"),
    ]),
    pet("parrot", "Parrot", "#d9332a", [
        Cube((-1.5, -5, -1.5), (3, 5, 3), "#d9332a"),
        Cube((-1.25, -7.4, -1.8), (2.5, 2.5, 2.5), "#e24a3a", details=eyes(1, 0, 2, "#ffffff")),
        Cube((-0.5, -6.4, -3.4), (1, 1.2, 1.2), "#ffc83a"),
        Cube((-2.3, -4.5, -1), (0.8, 3, 2), "#2e63d6"), Cube((1.5, -4.5, -1), (0.8, 3, 2), "#2e63d6"),
        Cube((-0.7, -1.2, 1.3), (1.4, 0.8, 3.5), "#2e63d6"),
    ]),
    pet("penguin", "Penguin", "#2b2e36", [
        Cube((-2, -5, -1.5), (4, 5, 3), "#22252b", details=[("front", 1, 1, 2, 3, "#f4f4f4")]),
        Cube((-1.75, -7.5, -1.75), (3.5, 2.5, 3.5), "#22252b", details=eyes(1, 0, 3, "#ffffff")),
        Cube((-0.7, -6.3, -3.2), (1.4, 0.8, 1.4), "#ff9a2e"),
        Cube((-2, -0.6, -2.2), (1.6, 0.6, 2), "#ff9a2e"), Cube((0.4, -0.6, -2.2), (1.6, 0.6, 2), "#ff9a2e"),
    ]),
    pet("frog", "Frog", "#4fb04a", [
        Cube((-2.5, -2.5, -2), (5, 2.5, 4), "#4fb04a", details=[("front", 1, 2, 3, 1, "#2f6b2a")]),
        Cube((-2.2, -4, -1.6), (1.5, 1.5, 1.5), "#6fd060", details=[("front", 0, 0, 1, 1, EYE)]),
        Cube((0.7, -4, -1.6), (1.5, 1.5, 1.5), "#6fd060", details=[("front", 1, 0, 1, 1, EYE)]),
    ], amp=1.6),
    pet("axolotl", "Axolotl", "#ffb3c7", [
        Cube((-1.5, -2.5, -3), (3, 2.5, 6), "#ffb3c7"),
        Cube((-2, -4.5, -3.8), (4, 2.5, 3), "#ffc2d1", details=eyes(1, 0, 3)),
        Cube((-2.8, -4.2, -3.2), (0.8, 1.6, 0.6), "#ff7aa0"), Cube((-2.8, -3, -3.2), (0.8, 1.2, 0.6), "#ff7aa0"),
        Cube((2, -4.2, -3.2), (0.8, 1.6, 0.6), "#ff7aa0"), Cube((2, -3, -3.2), (0.8, 1.2, 0.6), "#ff7aa0"),
        Cube((-0.5, -2.5, 3), (1, 2, 3), "#ff9fb8"),
    ]),
    pet("ghost", "Ghost", "#f2f4f8", [
        Cube((-2, -6, -2), (4, 5, 4), "#f2f4f8", details=[("front", 0, 1, 1, 2, EYE), ("front", 3, 1, 1, 2, EYE), ("front", 1, 3, 2, 1, "#6b7080")]),
        Cube((-2, -1, -2), (1.3, 1, 4), "#e4e7ee"), Cube((-0.65, -1, -2), (1.3, 1, 4), "#e4e7ee"), Cube((0.7, -1, -2), (1.3, 1, 4), "#e4e7ee"),
        Cube((-3, -4, -0.5), (1, 2, 1), "#e4e7ee"), Cube((2, -4, -0.5), (1, 2, 1), "#e4e7ee"),
    ], amp=2.2),
    pet("creeper_buddy", "Creeper Buddy", "#5ab04a", [
        Cube((-2, -8, -2), (4, 4, 4), "#5ab04a", details=eyes(1) + [("front", 1, 2, 2, 1, EYE), ("front", 1, 3, 1, 1, EYE), ("front", 2, 3, 1, 1, EYE)]),
        Cube((-1.5, -4, -1), (3, 3, 2), "#4a9a3c"),
        Cube((-1.5, -1, -1.6), (1.4, 1, 1.4), "#3f8a33"), Cube((0.1, -1, -1.6), (1.4, 1, 1.4), "#3f8a33"),
        Cube((-1.5, -1, 0.2), (1.4, 1, 1.4), "#3f8a33"), Cube((0.1, -1, 0.2), (1.4, 1, 1.4), "#3f8a33"),
    ]),
    pet("chick", "Chick", "#ffe85a", [
        Cube((-1.5, -3, -1.5), (3, 3, 3), "#ffe85a", details=eyes(1, 0, 2)),
        Cube((-0.5, -2.2, -2.6), (1, 0.8, 1.1), "#ff9a2e"),
        Cube((-2.2, -2.5, -0.5), (0.7, 1.5, 1.5), "#ffd028"), Cube((1.5, -2.5, -0.5), (0.7, 1.5, 1.5), "#ffd028"),
        Cube((-1, -0.5, -0.5), (0.6, 0.5, 1), "#ff9a2e"), Cube((0.4, -0.5, -0.5), (0.6, 0.5, 1), "#ff9a2e"),
    ], amp=1.6),
    pet("robot_buddy", "Robot Buddy", "#9aa4b0", [
        Cube((-2, -3, -2), (4, 3, 4), "#9aa4b0"),
        Cube((-2, -6.5, -2), (4, 3.5, 4), "#b9c3ce", details=eyes(1, 0, 3, "#38e0ff") + [("front", 1, 3, 2, 1, "#4a5560")]),
        Cube((-0.25, -9, -0.25), (0.5, 2.5, 0.5), "#6b7580"), Cube((-0.6, -10, -0.6), (1.2, 1.2, 1.2), "#ff4d4d"),
    ]),
    pet("pumpkin_pal", "Pumpkin Pal", "#e8821e", [
        Cube((-2.5, -4, -2.5), (5, 4, 5), "#e8821e", details=[("front", 1, 1, 1, 1, "#2a1500"), ("front", 3, 1, 1, 1, "#2a1500"), ("front", 1, 3, 3, 1, "#2a1500")]),
        Cube((-0.5, -5.5, -0.5), (1, 1.5, 1), "#4a8a2a"),
    ]),
    pet("snowman", "Mini Snowman", "#f4f8ff", [
        Cube((-2, -3, -2), (4, 3, 4), "#f4f8ff"),
        Cube((-1.5, -6, -1.5), (3, 3, 3), "#f8fbff", details=eyes(1, 0, 2)),
        Cube((-0.4, -4.8, -2.7), (0.8, 0.8, 1.3), "#ff8a2a"),
        Cube((-1.6, -7.6, -1.6), (3.2, 1.6, 3.2), "#1e1e24"),
        Cube((-3.4, -4.6, -0.3), (2, 0.4, 0.4), "#6b4a2a"), Cube((1.4, -4.6, -0.3), (2, 0.4, 0.4), "#6b4a2a"),
    ]),
    pet("owl", "Owl", "#8a6540", [
        Cube((-2, -4.5, -1.5), (4, 4.5, 3), "#8a6540", details=[("front", 1, 2, 2, 2, "#d9c7a0")]),
        Cube((-2, -6.5, -1.8), (4, 2.5, 3.6), "#9a7248", details=eyes(1, 0, 3, "#ffffff")),
        Cube((-2, -7.6, -1), (0.9, 1.4, 0.9), "#6d4e30"), Cube((1.1, -7.6, -1), (0.9, 1.4, 0.9), "#6d4e30"),
        Cube((-0.5, -5.3, -2.7), (1, 1, 1), "#ffb02e"),
        Cube((-2.7, -4, -1), (0.7, 3, 2), "#6d4e30"), Cube((2, -4, -1), (0.7, 3, 2), "#6d4e30"),
    ]),
]
COSMETICS.extend(MORE_PETS)


def main():
    os.makedirs(os.path.join(ROOT, "cosmetics"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "textures", "cosmetics"), exist_ok=True)
    out = []
    for cos in COSMETICS:
        cubes = [c for p in cos.parts for c in p.cubes]
        tw, th = pack(cubes)
        paint(cos, tw, th)
        out.append({
            "id": cos.id, "name": cos.name, "category": cos.category, "attach": cos.attach,
            "anim": cos.anim, "amp": cos.amp, "accent": cos.accent, "texture": cos.id, "texW": tw, "texH": th,
            "parts": [{
                "name": p.name, "pivot": list(p.pivot), "rot": list(p.rot),
                "cubes": [{"uv": list(c.uv), "pos": list(c.pos), "size": list(c.size), "inflate": c.inflate} for c in p.cubes],
            } for p in cos.parts],
        })
    with open(os.path.join(ROOT, "cosmetics", "cosmetics.json"), "w") as f:
        json.dump({"cosmetics": out}, f, indent=1)
    print("wrote", len(out), "cosmetics")


if __name__ == "__main__":
    main()
