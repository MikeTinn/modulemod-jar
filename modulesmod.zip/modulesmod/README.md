# Modules Mod (Fabric 1.21.11)

Client-side mod with 5 modules: Scoreboard, Tab, Aspect Ratio, Chat, Hitbox.
Open the settings from Mod Menu (Mods -> Modules Mod -> Configure button).

Working modules: Scoreboard, Tab, Aspect Ratio, Chat (also: /chatsearch).
Settings are saved to config/modulesmod.json.

Build: push to GitHub, Actions tab -> Build -> download the jar artifact.
