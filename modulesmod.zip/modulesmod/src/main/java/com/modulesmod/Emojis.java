package com.modulesmod;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Emoji shortcodes like :heart: turned into symbols that Minecraft's normal font can draw.
 * Real emoji (the colourful ones) are NOT in Minecraft's font, so they would show as boxes for
 * other players. These symbols are plain characters, so every player sees them without any mod.
 */
public final class Emojis {
	private static final Map<String, String> MAP = new HashMap<>();
	private static final Pattern CODE = Pattern.compile(":([a-zA-Z0-9_+\\-]{1,24}):");

	static {
		put("heart", "\u2764");
		put("hearts", "\u2665");
		put("star", "\u2605");
		put("star2", "\u2606");
		put("smile", "\u263A");
		put("smiley", "\u263B");
		put("sad", "\u2639");
		put("check", "\u2714");
		put("yes", "\u2714");
		put("x", "\u2716");
		put("no", "\u2716");
		put("cross", "\u271D");
		put("sun", "\u2600");
		put("cloud", "\u2601");
		put("umbrella", "\u2602");
		put("snowman", "\u2603");
		put("snowflake", "\u2744");
		put("skull", "\u2620");
		put("peace", "\u262E");
		put("yinyang", "\u262F");
		put("music", "\u266A");
		put("notes", "\u266B");
		put("spades", "\u2660");
		put("clubs", "\u2663");
		put("diamonds", "\u2666");
		put("flower", "\u2740");
		put("sparkles", "\u2726");
		put("crown", "\u265B");
		put("phone", "\u260E");
		put("radioactive", "\u2622");
		put("biohazard", "\u2623");
		put("warning", "\u26A0");
		put("zap", "\u26A1");
		put("bolt", "\u26A1");
		put("swords", "\u2694");
		put("anchor", "\u2693");
		put("coffee", "\u2615");
		put("scissors", "\u2702");
		put("plane", "\u2708");
		put("mail", "\u2709");
		put("pencil", "\u270F");
		put("victory", "\u270C");
		put("gear", "\u2699");
		put("hourglass", "\u231B");
		put("arrow_right", "\u2192");
		put("arrow_left", "\u2190");
		put("arrow_up", "\u2191");
		put("arrow_down", "\u2193");
		put("infinity", "\u221E");
		put("copyright", "\u00A9");
		put("tm", "\u2122");
		put("heart_eyes", "\u2665\u203F\u2665");
		put("cat", "=^\uFF65\u03C9\uFF65^=");
		put("shrug", "\u00AF\\_(\u30C4)_/\u00AF");
		put("tableflip", "(\u256F\u00B0\u25A1\u00B0)\u256F\uFE35 \u253B\u2501\u253B");
		put("unflip", "\u252C\u2500\u252C \u30CE( \u309C-\u309C\u30CE)");
	}

	private Emojis() {}

	public static Map<String, String> all() {
		return MAP;
	}

	/** Replaces known :shortcodes: (and optionally text faces like :) and <3). */
	public static String replace(String text, boolean faces) {
		if (text == null || text.isEmpty()) return text;
		String out = text;
		if (out.indexOf(':') >= 0) {
			Matcher m = CODE.matcher(out);
			StringBuilder sb = new StringBuilder();
			while (m.find()) {
				String rep = MAP.get(m.group(1).toLowerCase(Locale.ROOT));
				m.appendReplacement(sb, Matcher.quoteReplacement(rep != null ? rep : m.group()));
			}
			m.appendTail(sb);
			out = sb.toString();
		}
		if (faces && !out.contains("://")) {
			out = out.replace(":)", "\u263A").replace(":(", "\u2639").replace("<3", "\u2764").replace(":D", "\u263B");
		}
		return out;
	}
}
