package com.modulesmod;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import net.minecraft.world.debug.gizmo.TextGizmo;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Synced lyrics as text floating in the world around your crosshair.
 *  - The song comes from MediaReader (Windows media session).
 *  - The lyrics come from LRCLIB (lrclib.net) using the song title, artist, album and length.
 *  - LRCLIB only has line timings, so the time of every word is spread over its line by word length.
 *  - Each word is placed in the world when it is sung and fades out again; it stays where it was
 *    placed, so you can turn around and see it hanging in the air.
 * Called every frame from DebugRendererMixin (inside the gizmo collector, like the hitboxes).
 */
public final class LyricsController {
	private record Word(long startMs, String text, int lineIdx, int charStart, int lineChars,
						long lineStartMs, long lineEndMs, String lineText) {}

	private static final class Piece {
		String text;
		Vec3d pos;
		long born;
		long life;
		float scale;
		int rgb;
	}

	private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();
	private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
		Thread t = new Thread(r, "modulesmod-lyrics");
		t.setDaemon(true);
		return t;
	});
	private static final Pattern STAMP = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]");
	private static final Random RNG = new Random();

	/** Words of the current song in time order. Replaced as a whole by the download thread. */
	private static volatile List<Word> words = List.of();
	private static volatile String requestedKey = "";

	/** For the GUI display: which word is being sung (index into words) and whether we are between lines. */
	private static volatile int hudSeq = -1;
	private static volatile boolean hudGap = false;

	private static final List<Piece> pieces = new ArrayList<>();
	private static boolean running = false;
	private static int lastSeq = -1;
	private static int lastLineShown = -1;
	private static int anchorLine = -1;
	private static Vec3d anchorCenter = Vec3d.ZERO;
	private static Vec3d anchorRight = Vec3d.ZERO;

	private LyricsController() {}

	// ------------------------------------------------------------------ per frame

	public static void emit(float tickProgress) {
		if (!Modules.LYRICS.isEnabled()) {
			if (running) {
				MediaReader.stop();
				running = false;
				pieces.clear();
				requestedKey = "";
				Diagnostics.lyrics = "off";
			}
			return;
		}
		try {
			tick();
		} catch (Exception e) {
			Diagnostics.error("lyrics", e);
		}
	}

	private static void tick() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.world == null) return;
		if (!running) {
			MediaReader.start();
			running = true;
		}
		long now = System.currentTimeMillis();
		MediaReader.Track t = MediaReader.get();
		if (t == null) {
			hudSeq = -1;
			if (MediaReader.supported()) Diagnostics.lyrics = "no song detected";
			draw(now);
			return;
		}

		String key = t.artist() + "\u0001" + t.title();
		if (!key.equals(requestedKey)) {
			requestedKey = key;
			words = List.of();
			hudSeq = -1;
			lastSeq = -1;
			lastLineShown = -1;
			anchorLine = -1;
			pieces.clear();
			Diagnostics.lyrics = "looking up lyrics for " + t.title();
			POOL.execute(() -> load(t, key));
		}

		List<Word> list = words;
		boolean gui = Modules.LY_DISPLAY.index() == 1;
		if (!list.isEmpty()) {
			long pos = t.positionMs() + (t.playing() ? now - t.receivedAtMs() : 0) + (long) Modules.LY_OFFSET.num;
			if (gui) {
				hudSeq = seqAt(list, pos);
				hudGap = hudSeq >= 0 && pos > list.get(hudSeq).lineEndMs() + 3000;
			} else if (t.playing()) {
				spawnDue(mc, list, pos, now);
			}
		} else {
			hudSeq = -1;
		}
		if (gui) pieces.clear();
		else draw(now);
	}

	/** Index of the last word whose start time has passed, or -1 before the first word. */
	private static int seqAt(List<Word> list, long pos) {
		int lo = 0;
		int hi = list.size() - 1;
		int seq = -1;
		while (lo <= hi) {
			int mid = (lo + hi) >>> 1;
			if (list.get(mid).startMs() <= pos) {
				seq = mid;
				lo = mid + 1;
			} else {
				hi = mid - 1;
			}
		}
		return seq;
	}

	private static void spawnDue(MinecraftClient mc, List<Word> list, long pos, long now) {
		int seq = seqAt(list, pos);
		if (seq < 0 || seq == lastSeq) return;
		int from = (lastSeq >= 0 && seq > lastSeq && seq - lastSeq <= 3) ? lastSeq + 1 : seq;
		lastSeq = seq;
		boolean linesMode = Modules.LY_SHOW.index() == 1;
		for (int i = from; i <= seq; i++) {
			Word w = list.get(i);
			if (linesMode) {
				if (w.lineIdx() != lastLineShown) {
					lastLineShown = w.lineIdx();
					spawn(mc, w, w.lineText(), i, true, now);
				}
			} else {
				spawn(mc, w, w.text(), i, false, now);
			}
		}
	}

	private static void spawn(MinecraftClient mc, Word w, String text, int index, boolean wholeLine, long now) {
		Vec3d eye = mc.player.getEyePos();
		double yaw = Math.toRadians(mc.player.getYaw());
		double pitch = Math.toRadians(mc.player.getPitch());
		Vec3d dir = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
		Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
		Vec3d up = right.crossProduct(dir);

		double dist = Modules.LY_DISTANCE.num;
		double spread = Modules.LY_SPREAD.num;
		float size = (float) Modules.LY_SIZE.num;
		Vec3d center = lift(mc, eye.add(dir.multiply(dist)));
		Vec3d pos;

		if (wholeLine) {
			pos = center;
		} else if (Modules.LY_LAYOUT.index() == 1) {
			// "Center": the words of one line sit in a row, the row stays where the line began
			if (anchorLine != w.lineIdx()) {
				anchorLine = w.lineIdx();
				anchorCenter = center;
				anchorRight = right;
			}
			double charW = 0.09 * size;
			double x = (w.charStart() + w.text().length() / 2.0 - w.lineChars() / 2.0) * charW;
			pos = anchorCenter.add(anchorRight.multiply(x));
		} else {
			// "Scatter": anywhere on a ring-ish area around the crosshair, never exactly on it
			double ang = RNG.nextDouble() * Math.PI * 2;
			double r = spread * (0.35 + 0.65 * Math.sqrt(RNG.nextDouble()));
			pos = lift(mc, center.add(right.multiply(Math.cos(ang) * r * 1.4)).add(up.multiply(Math.sin(ang) * r * 0.8)));
		}

		Piece p = new Piece();
		p.text = LyricsFonts.apply(text, Modules.LY_FONT.index());
		p.pos = pos;
		p.born = now;
		p.scale = size;
		p.life = wholeLine
				? Math.max(1500L, w.lineEndMs() - w.lineStartMs() + 700)
				: (long) Modules.LY_LIFETIME.num;
		p.rgb = Modules.LY_RAINBOW.bool
				? HudUtil.hsvToRgb((index * 0.07f) % 1f, 0.6f, 1f)
				: HudUtil.rgb(Modules.LY_COLOR.str, 0xFFFFFF);
		pieces.add(p);
		if (pieces.size() > 80) pieces.remove(0);
	}

	/**
	 * Keeps text at least "Min Height Above Ground" blocks above the first solid block (or water)
	 * under it, so it never sits in the terrain. Only ever moves the text up.
	 */
	private static Vec3d lift(MinecraftClient mc, Vec3d pos) {
		double min = Modules.LY_HEIGHT.num;
		if (min <= 0 || mc.world == null) return pos;
		int x = (int) Math.floor(pos.x);
		int z = (int) Math.floor(pos.z);
		int top = (int) Math.floor(pos.y);
		int bottom = Math.max(mc.world.getBottomY(), top - 96);
		BlockPos.Mutable bp = new BlockPos.Mutable();
		for (int y = top; y >= bottom; y--) {
			bp.set(x, y, z);
			var state = mc.world.getBlockState(bp);
			if (!state.getCollisionShape(mc.world, bp).isEmpty() || !state.getFluidState().isEmpty()) {
				double wanted = y + 1 + min;
				return pos.y < wanted ? new Vec3d(pos.x, wanted, pos.z) : pos;
			}
		}
		return pos;
	}

	private static void draw(long now) {
		Iterator<Piece> it = pieces.iterator();
		while (it.hasNext()) {
			Piece p = it.next();
			long age = now - p.born;
			if (age > p.life) {
				it.remove();
				continue;
			}
			float in = Math.min(1f, age / 160f);
			float fadeStart = p.life * 0.6f;
			float out = age > fadeStart ? 1f - (age - fadeStart) / (p.life - fadeStart) : 1f;
			float a = in * out;
			int alpha = Math.round(255 * a);
			if (alpha < 4) continue;
			float ease = 1f - (1f - in) * (1f - in) * (1f - in);
			float pop = 0.75f + 0.25f * ease;
			Vec3d at = p.pos.add(0, 0.12 * ease, 0);
			drawText(p.text, at, (alpha << 24) | p.rgb, p.scale * pop);
		}
	}

	/**
	 * The ONLY place that touches the game's text gizmo. If a Minecraft update renames something,
	 * this is the one method to fix.
	 */
	private static void drawText(String text, Vec3d pos, int argb, float scale) {
		GizmoDrawing.text(text, pos, TextGizmo.Style.centered(argb).scaled(scale));
	}

	// ------------------------------------------------------------------ lyrics download

	private static void load(MediaReader.Track t, String key) {
		try {
			List<long[]> stamps = new ArrayList<>();
			List<String> texts = new ArrayList<>();
			String lrc = fetchSynced(t);
			if (lrc == null) {
				if (key.equals(requestedKey)) Diagnostics.lyrics = "no synced lyrics found for " + t.title();
				return;
			}
			parseLrc(lrc, stamps, texts);
			List<Word> built = buildWords(stamps, texts);
			if (key.equals(requestedKey)) {
				words = built;
				Diagnostics.lyrics = built.size() + " words ready for " + t.title();
			}
		} catch (Exception e) {
			Diagnostics.error("lyrics download", e);
			if (key.equals(requestedKey)) Diagnostics.lyrics = "lyrics download failed";
		}
	}

	private static String fetchSynced(MediaReader.Track t) throws Exception {
		StringBuilder q = new StringBuilder("track_name=").append(enc(t.title()))
				.append("&artist_name=").append(enc(t.artist()));
		if (!t.album().isEmpty()) q.append("&album_name=").append(enc(t.album()));
		if (t.durationMs() > 0) q.append("&duration=").append(Math.round(t.durationMs() / 1000.0));
		String body = get("https://lrclib.net/api/get?" + q);
		if (body != null) {
			String s = synced(JsonParser.parseString(body));
			if (s != null) return s;
		}
		// not an exact match: take the first search result that has synced lyrics
		String searchBody = get("https://lrclib.net/api/search?track_name=" + enc(t.title())
				+ "&artist_name=" + enc(t.artist()));
		if (searchBody != null) {
			JsonElement root = JsonParser.parseString(searchBody);
			if (root.isJsonArray()) {
				JsonArray arr = root.getAsJsonArray();
				for (JsonElement e : arr) {
					String s = synced(e);
					if (s != null) return s;
				}
			}
		}
		return null;
	}

	private static String synced(JsonElement e) {
		if (e == null || !e.isJsonObject()) return null;
		JsonObject o = e.getAsJsonObject();
		JsonElement s = o.get("syncedLyrics");
		if (s == null || s.isJsonNull()) return null;
		String str = s.getAsString();
		return str.isBlank() ? null : str;
	}

	private static String get(String url) throws Exception {
		HttpRequest req = HttpRequest.newBuilder(URI.create(url))
				.timeout(Duration.ofSeconds(10))
				.header("User-Agent", "modulesmod/" + ModulesMod.MOD_ID + " (Minecraft mod)")
				.GET().build();
		HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
		return res.statusCode() == 200 ? res.body() : null;
	}

	private static String enc(String s) {
		return URLEncoder.encode(s, StandardCharsets.UTF_8);
	}

	/** "[01:23.45] some words" (also several stamps on one line) -> start times and texts. */
	private static void parseLrc(String lrc, List<long[]> stamps, List<String> texts) {
		for (String raw : lrc.split("\\R")) {
			Matcher m = STAMP.matcher(raw);
			List<Long> times = new ArrayList<>();
			int end = 0;
			while (m.find()) {
				long min = Long.parseLong(m.group(1));
				long sec = Long.parseLong(m.group(2));
				long ms = 0;
				String frac = m.group(3);
				if (frac != null) {
					ms = frac.length() >= 3 ? Long.parseLong(frac.substring(0, 3))
							: Long.parseLong(frac) * (frac.length() == 1 ? 100 : 10);
				}
				times.add(min * 60_000 + sec * 1000 + ms);
				end = m.end();
			}
			if (times.isEmpty()) continue;
			String text = raw.substring(end).trim();
			for (long tm : times) {
				stamps.add(new long[]{tm});
				texts.add(text);
			}
		}
		// keep both lists in time order
		Integer[] order = new Integer[stamps.size()];
		for (int i = 0; i < order.length; i++) order[i] = i;
		java.util.Arrays.sort(order, Comparator.comparingLong(i -> stamps.get(i)[0]));
		List<long[]> s2 = new ArrayList<>();
		List<String> t2 = new ArrayList<>();
		for (Integer i : order) {
			s2.add(stamps.get(i));
			t2.add(texts.get(i));
		}
		stamps.clear();
		stamps.addAll(s2);
		texts.clear();
		texts.addAll(t2);
	}

	/** Splits every line into words and spreads the line's time over them by word length. */
	private static List<Word> buildWords(List<long[]> stamps, List<String> texts) {
		List<Word> out = new ArrayList<>();
		for (int i = 0; i < stamps.size(); i++) {
			String line = texts.get(i);
			if (line.isEmpty()) continue;
			long start = stamps.get(i)[0];
			long nextStart = i + 1 < stamps.size() ? stamps.get(i + 1)[0] : start + 5000;
			long span = Math.max(300, Math.min(nextStart - start, 7000) - 150);
			long lineEnd = start + span;

			String[] parts = line.split("\\s+");
			int total = 0;
			for (String p : parts) total += p.length() + 1;
			int cum = 0;
			int charPos = 0;
			for (String p : parts) {
				long ws = start + Math.round(span * (cum / (double) total));
				out.add(new Word(ws, p, i, charPos, line.length(), start, lineEnd, line));
				cum += p.length() + 1;
				charPos += p.length() + 1;
			}
		}
		return out;
	}

	// ------------------------------------------------------------------ GUI display

	/** What the GUI display shows: words already sung, words still to come, and the line after. */
	public record HudLine(String sung, String rest, String next) {}

	public static HudLine hudLine() {
		List<Word> list = words;
		int seq = hudSeq;
		if (list.isEmpty() || seq < 0 || seq >= list.size()) return null;
		if (hudGap) return new HudLine("\u266A", "", "");
		Word w = list.get(seq);
		int first = seq;
		while (first > 0 && list.get(first - 1).lineIdx() == w.lineIdx()) first--;
		int last = seq;
		while (last + 1 < list.size() && list.get(last + 1).lineIdx() == w.lineIdx()) last++;
		StringBuilder sung = new StringBuilder();
		for (int i = first; i <= seq; i++) {
			if (i > first) sung.append(' ');
			sung.append(list.get(i).text());
		}
		StringBuilder rest = new StringBuilder();
		for (int i = seq + 1; i <= last; i++) {
			if (i > seq + 1) rest.append(' ');
			rest.append(list.get(i).text());
		}
		String next = last + 1 < list.size() ? list.get(last + 1).lineText() : "";
		return new HudLine(sung.toString(), rest.toString(), next);
	}

	// ------------------------------------------------------------------ status button

	public static void printStatus() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;
		MediaReader.Track t = MediaReader.get();
		String song = t == null ? "none detected" : t.artist() + " - " + t.title() + (t.playing() ? " (playing)" : " (paused)");
		mc.player.sendMessage(Text.literal("[Lyrics] song: " + song), false);
		mc.player.sendMessage(Text.literal("[Lyrics] status: " + Diagnostics.lyrics), false);
		if (!Modules.LYRICS.isEnabled()) {
			mc.player.sendMessage(Text.literal("[Lyrics] the module is switched off, so nothing is looked up"), false);
		}
	}
}
