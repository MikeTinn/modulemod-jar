package com.modulesmod;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ModulesMod implements ClientModInitializer {
	public static final String MOD_ID = "modulesmod";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitializeClient() {
		Modules.load();
		ScoreboardHud.register();
		TabHud.register();
	}
}
