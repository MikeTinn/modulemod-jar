package com.modulesmod.mixin;

import com.modulesmod.ChatRenderHook;
import com.modulesmod.ChatTransformer;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * All injections use require = 0: if a Minecraft update renames something, the game still starts
 * and only that one chat feature stops working.
 */
@Mixin(ChatHud.class)
public class ChatHudMixin {
	/** Every message passes through here before it is split into lines and stored. */
	@ModifyVariable(
			method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
			at = @At("HEAD"), argsOnly = true, require = 0)
	private Text modulesmod$transform(Text message) {
		return ChatTransformer.transform(message);
	}

	/** Vanilla keeps only the last 100 messages. */
	@ModifyConstant(method = {"addMessage", "addVisibleMessage"},
			constant = @Constant(intValue = 100), require = 0)
	private int modulesmod$maxLines(int vanilla) {
		return ChatTransformer.maxLines(vanilla);
	}

	/** Chat size: multiplies vanilla's chat scale. */
	@Inject(method = "getChatScale", at = @At("RETURN"), cancellable = true, require = 0)
	private void modulesmod$scale(CallbackInfoReturnable<Double> cir) {
		double m = ChatTransformer.sizeMultiplier();
		if (m != 1.0) cir.setReturnValue(cir.getReturnValue() * m);
	}

	@Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;IIIZZ)V",
			at = @At("HEAD"), require = 0)
	private void modulesmod$renderHead(DrawContext ctx, TextRenderer tr, int tick, int mouseX, int mouseY,
									   boolean a, boolean b, CallbackInfo ci) {
		ChatRenderHook.begin(ctx, ((ChatHud) (Object) this).getChatScale());
	}

	@Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;IIIZZ)V",
			at = @At("RETURN"), require = 0)
	private void modulesmod$renderReturn(DrawContext ctx, TextRenderer tr, int tick, int mouseX, int mouseY,
										 boolean a, boolean b, CallbackInfo ci) {
		ChatRenderHook.end(ctx);
	}
}
