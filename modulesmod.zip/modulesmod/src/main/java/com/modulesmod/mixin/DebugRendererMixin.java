package com.modulesmod.mixin;

import com.modulesmod.BlockOutlineRenderer;
import com.modulesmod.HitboxRenderer;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.debug.DebugRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Runs every frame inside the game's gizmo collector, which is where our hitboxes are drawn. */
@Mixin(DebugRenderer.class)
public class DebugRendererMixin {
	@Inject(method = "render(Lnet/minecraft/client/render/Frustum;DDDF)V", at = @At("RETURN"), require = 0)
	private void modulesmod$hitboxes(Frustum frustum, double cameraX, double cameraY, double cameraZ,
									 float tickProgress, CallbackInfo ci) {
		HitboxRenderer.emit(tickProgress);
		BlockOutlineRenderer.emit(tickProgress);
	}
}
