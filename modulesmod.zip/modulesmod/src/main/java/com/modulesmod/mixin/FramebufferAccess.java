package com.modulesmod.mixin;

import com.mojang.blaze3d.textures.FilterMode;
import net.minecraft.client.gl.Framebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Lets the Upscaler choose smooth or sharp stretching of the main buffer. The game's own method for
 * this is private. Optional mixin config: if Minecraft renames it, only the filter choice stops working.
 */
@Mixin(Framebuffer.class)
public interface FramebufferAccess {
	@Invoker("setFilter")
	void modulesmod$setFilter(FilterMode filter, boolean force);
}
