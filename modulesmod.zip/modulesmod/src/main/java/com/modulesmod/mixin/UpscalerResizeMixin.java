package com.modulesmod.mixin;

import com.modulesmod.Upscaler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Whenever the game resizes its main screen buffer to the window size (window resize, GUI scale change),
 * make the buffer the scaled size instead. Optional mixin config: if the call is not found the Upscaler
 * simply does nothing.
 */
@Mixin(MinecraftClient.class)
public abstract class UpscalerResizeMixin {
	@Redirect(method = "onResolutionChanged", at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/gl/Framebuffer;resize(II)V"), require = 0)
	private void modulesmod$scaledResize(Framebuffer framebuffer, int width, int height) {
		Upscaler.hookSeen = true;
		framebuffer.resize(Upscaler.scale(width), Upscaler.scale(height));
	}
}
